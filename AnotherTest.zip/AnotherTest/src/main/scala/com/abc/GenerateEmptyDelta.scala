package com.abc

/**
  *
  */
object GenerateEmptyDelta extends Context {


  def main(args: Array[String]): Unit = {
    /* val df_csv = sparkSession.read.format("csv").option("header","true").option("inferschema","true")
       .load("C:\\Users\\pmaremal\\Documents\\cdcframework\\src\\main\\resources\\baseline\\insurance.csv").show()*/
    val _source = args(0).toString
    val _dest = args(1).toString
    val filetype=args(2).toString

    if (filetype == "avro" ) {
    val df_avro = sparkSession.read
      .format("com.databricks.spark.avro")
      .load(_source)
    df_avro.createOrReplaceGlobalTempView("avro_stg")
    sparkSession.sql("select * from global_temp.avro_stg where 1=0").write.mode("overwrite").format("com.databricks.spark.avro")
      .save(_dest)
      val allcolumns = df_avro.schema.fields.map(x => x.name).filterNot(_.startsWith("md5")).toList
      println(allcolumns)
      val audcolumns= List("runid","jobrundate")
      val matchingcolumns=allcolumns.diff(audcolumns)
      matchingcolumns.foreach(x => print("\"" +x+ "\""+","))
    }
    else if(filetype == "parquet") {
      val df_parquet = sparkSession.read.parquet(_source)
      df_parquet.createOrReplaceGlobalTempView("parquet_stg")
      sparkSession.sql("select * from global_temp.parquet_stg where 1=0").write.mode("overwrite").parquet(_dest)

    }
  }

}
