package com.abc

import com.aig.datalake.lc.model._
import org.apache.spark.sql
// import org.apache.hadoop.conf._
import net.liftweb.json._
import org.apache.hadoop.fs.{FileSystem, _}

import scala.io.Source
import scala.sys.process._


// import scala.xml._
import org.apache.spark.sql.types._

import scala.collection.mutable.ListBuffer

object helper extends Context {
  /*  private val conf = new Configuration()
    private val fileSystem = FileSystem.get(conf)

    def getFilesWithExtension(folderPath: String, extension: String): List[(String, String)] = {
      val path = new Path(folderPath)
      if (fileSystem.exists(path) && fileSystem.isDirectory(path)) {
        val files = fileSystem.listStatus(path)
        files.filter(f => f.isFile() && f.getPath.toString().toLowerCase().endsWith(s".${extension}")).map {
          case f => (f.getPath.toString(), f.getPath.getName.toLowerCase.replaceAll(s".${extension}", ""))
        }.toList
      } else {
        List.empty
      }
    }*/
  val conf = new org.apache.hadoop.conf.Configuration()

  def getCDCFieldsFromJson2(jsonSchemaFile: String) = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val m = (parsedJson \\ "matching").extract[Matching]
    val (cdc, baselinefileformat, inputfileformat, cdctype, comparisontype, compareinputpath, archivelocation, keycloumns, matchcolumns, outputfileformat, outputgenerationtype, baseline, inserts, updates, deletes, delta, duplicates, deleteidentifiercolumn, deleteflag, delboolean) =
      (m.CDC, m.baselinefileformat, m.inputfileformat, m.cdcType, m.comparisontype, m.compareinputpath, m.archivelocation, m.keyColumns, m.matchColumns, m.outputfileformat, m.outputgenerationtype, m.baseline, m.inserts, m.updates, m.deletes, m.delta, m.duplicates, m.deleteidentifiercolumn, m.deleteflag, m.delboolean)
    (cdc, baselinefileformat, inputfileformat, cdctype, comparisontype,
      compareinputpath, archivelocation, keycloumns, matchcolumns, outputfileformat,
      outputgenerationtype, baseline, inserts, updates, deletes,
      delta, duplicates, deleteidentifiercolumn, deleteflag, delboolean)
  }

  def getCDCFieldsFromJson(jsonSchemaFile: String): Matching = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val m = (parsedJson \\ "matching").extract[Matching]
    m
  }

  def getDupHandlingFieldsFromJson(jsonSchemaFile: String): HandingDuplicates = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val m = (parsedJson \\ "matching").extract[HandingDuplicates]
    m
  }

  def getStagingFieldsFromJson(jsonSchemaFile: String): StagingLocation = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val m = (parsedJson \\ "matching" \\ "stagingLocation").extract[StagingLocation]
    m
  }

  def getLogsFieldsFromJson(jsonSchemaFile: String): CdcLogs = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val m = (parsedJson \\ "matching" \\ "cdclogs").extract[CdcLogs]
    m
  }

  /*def getoutputPropertiesFromJson(jsonSchemaFile: String): OutputProperties = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val o  = (parsedJson \\ "Outputs" \\ "Output" \\ "outputProperties").extract[OutputProperties]
    o
  }*/

  def getLogsFieldsFromJson2(jsonSchemaFile: String) = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val m = (parsedJson \\ "matching" \\ "cdclogs").extract[CdcLogs]
    val (detailedlogs, statlogs) = (m.detailedlogs, m.statlogs)
    (detailedlogs, statlogs)

  }

  import scala.collection.JavaConversions._


  def getKeysFromJson(jsonSchemaFile: String) = {
    var reqCol = new ListBuffer[String]()
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    implicit val formats = DefaultFormats
    val forecast = (parsedJson \\ "keys").values
    forecast
  }

  def populateJsonmetadata(jsonSchemaFile: String) = {
    val json = Source.fromFile(jsonSchemaFile)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    var table_name = (parsedJson \\ "table_name").values.toString
    var source_system = (parsedJson \\ "sourceSystem").values.toString
    var table_desc = (parsedJson \\ "table_desc").values.toString
    var delimiter = (parsedJson \\ "delimiter").values.toString
    (table_name, source_system, table_desc, delimiter)
  }


  def isDirectoryExists(folder: String): Boolean = {
    val fs = FileSystem.get(new java.net.URI(folder), sparkSession.sparkContext.hadoopConfiguration)
    val ispresent = fs.exists(new Path(folder))
    ispresent
  }

  def moveFile(src : String ,Dest : String,mode : String ) ={
    val _dateFormatFile = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val _date= _dateFormatFile.format( new java.util.Date())
    import sys.process._
    val cmd = "aws s3 mv " + src +" " +"s3://"+Dest+"/"+" "+ mode
    println(cmd)
    cmd.toString.!
  }

  def copyFile(src: String, Dest: String, mode: String) = {
    val _dateFormatFile = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val _date = _dateFormatFile.format(new java.util.Date())
    import sys.process._
    val cmd = "aws s3 cp " + src + " " + "s3://" + Dest + "/" + " " + mode
    println(cmd)
    cmd.toString.!
  }

  def removeFile(src: String, mode: String) = {
    val _dateFormatFile = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val _date = _dateFormatFile.format(new java.util.Date())
    val cmd = "aws s3 rm " + "s3://" + src + "/" + " " + mode
    println(cmd)
    cmd.toString.!
  }

  def getBucketKey(sourcePath: String) = {
    val (bucket, key) = (sourcePath.split("//").tail.mkString.split("/").head, sourcePath.split("//").tail.mkString.split("/").tail.mkString("/"))
    (bucket, key)
  }

}