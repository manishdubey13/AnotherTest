package com.abc

object CdcComparisonType extends Enumeration {
  type CdcComparisonType = Value
  val DELTA, FULL = Value
}
