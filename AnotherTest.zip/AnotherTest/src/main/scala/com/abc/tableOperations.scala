/**
  * Created by Ajay on 2018-May 20
  */
package com.abc

import java.util
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{StringType, _}


object tableOperations extends Context {

  @transient lazy val log: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)

  val logFile = new LogBuilder
  val _logFormat = new java.text.SimpleDateFormat("yyyy-MM-dd")
  val logTime: String = _logFormat.format(new java.util.Date())
  val _dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val startTime: Broadcast[String] = sc.broadcast(_dateFormat.format(new java.util.Date()))

  logFile.add("STATS", "INFO", "Job Started :" + startTime.value)
  logFile.add("SPARKAPP", "INFO", "Spark application id :" + sparkSession.conf.get("spark.app.id"))

  /**
    * This method creates the base dataframe/daily dataframe with the below inputs
    *
    * @param fileName             -- basefile/daily file
    * @param fileType             -- avro/csv/parquet
    * @param stgTable             -- Staging table
    * @param matchColumns         -- Columns used for finding the cdc
    * @param keyCols              -- primary /composite key columns
    * @param stgTableWithHashCols -- Staging table used for holding for allcolumns + hash columns
    * @return -- DataFrame
    */
  def createDfWithHashKeys(fileName: String, fileType: String, stgTable: String,
                           matchColumns: String, keyCols: String,
                           stgTableWithHashCols: String, detailedLogsLocation: String): DataFrame = {

    logFile.add("PROCESS", "INFO", "CDC STARTED FOR :" + fileName)
    val df = TypeFactory(fileType, sparkSession).readFile(fileName)
    df.createOrReplaceGlobalTempView(stgTable)
    val allColumns = df.schema.fields.map(x => x.name).toList.mkString(",")
    val colDataTypes = df.schema.fields.map(x => (x.name, x.dataType)).toList
    val concatsql : util.ArrayList[String] = new util.ArrayList[String]()
    /*if(fileType == "parquet") {
      for ((colname, dtp) <- colDataTypes) {
        dtp match {
          case TimestampType | DateType => concatsql.add("CAST(" + colname + " as long) as " + colname)
          case _ => concatsql.add(colname)
        }
      }
    }*/
    val sqlconcatStatement = StringUtils.join(concatsql, ",")
    val matchColumns_ = matchColumns.split(",").toList
    val concatBuilder = new util.ArrayList[String]()

    val _keycols = keyCols.split(",").toList
    val concatBuilderKeyCols: util.ArrayList[String] = new util.ArrayList[String]()


    colDataTypes.filter { d => _keycols.exists(_ == d._1) }.foreach {
      x =>
        x._2 match {
          //case IntegerType |FloatType|DoubleType  => concatBuilder.add("cast(coalesce("+x._1+","+"\'"+"null"+"\'"+") as String)")
          case IntegerType | FloatType | DoubleType => concatBuilderKeyCols.add("nvl2(" + x._1 + ",cast(" + x._1 + " as double),cast(" + "\'" + x._1 + "\'" + " as String))")
          case StringType => concatBuilderKeyCols.add("coalesce(trim(" + x._1 + ")," + "\'" + "null" + "\'" + ")")
         //  case TimestampType | DateType => concatBuilderKeyCols.add("cast(coalesce(" + x._1 + "," + "\'" + "null" + "\'" + ")as long)")
          case _ => concatBuilderKeyCols.add("cast(coalesce(" + x._1 + "," + "\'" + "null" + "\'" + ") as string)")
        }
    }

    colDataTypes.filter {
      d => matchColumns_.exists(_ == d._1)
    }.foreach {
      x =>
        x._2 match {
          case IntegerType | FloatType | DoubleType => concatBuilder.add(
            "nvl2(" + x._1 + ",cast(" + x._1 + " as double),cast(" + "\'"
              + x._1 + "\'" + " as String))")
          case StringType => concatBuilder.add("coalesce(trim(" + x._1 + ")," + "\'"
            + "null" + "\'" + ")")
         //  case TimestampType | DateType => concatBuilderKeyCols.add("cast(coalesce(" + x._1 + "," + "\'" + "null" + "\'" + ")as long)")
          case _ => concatBuilder.add("cast(coalesce(" + x._1 + "," + "\'"
            + "null" + "\'" + ") as string)")
        }
    }
    val concatStatement = StringUtils.join(concatBuilder, ",")
    val keysConcatStatement = StringUtils.join(concatBuilderKeyCols, ",")

   /* if (fileType == "parquet") {
    val sqlText = "select distinct " + sqlconcatStatement +
      ",sha1(concat(" + concatStatement + ")) as nonkeyhash,sha1(concat(" +
      keysConcatStatement + ")) as keyhash from global_temp." + stgTable
      sparkSession.sql(sqlText).createOrReplaceGlobalTempView(stgTableWithHashCols)
      logFile.add("QUERY", "INFO", "QUERY TO GET COLUMNS, HASHKEYS : " + sqlText)
    }
    else {
    val sqlText = "select distinct " + allColumns +
      ",sha1(concat(" + concatStatement + ")) as nonkeyhash,sha1(concat(" +
      keysConcatStatement + ")) as keyhash from global_temp." + stgTable
      sparkSession.sql(sqlText).createOrReplaceGlobalTempView(stgTableWithHashCols)
      logFile.add("QUERY", "INFO", "QUERY TO GET COLUMNS, HASHKEYS : " + sqlText)
    }*/

    val sqlText = "select distinct " + allColumns +
      ",sha1(concat(" + concatStatement + ")) as nonkeyhash,sha1(concat(" +
      keysConcatStatement + ")) as keyhash from global_temp." + stgTable
    sparkSession.sql(sqlText).createOrReplaceGlobalTempView(stgTableWithHashCols)
    logFile.add("QUERY", "INFO", "QUERY TO GET COLUMNS, HASHKEYS : " + sqlText)
     val stgDF = sparkSession.sql("select * from global_temp."
      + stgTableWithHashCols)
    stgDF.toDF()

  }
}