package com.abc.datalake.lc.model

case class field(field_name: String, field_type: String, field_length: String, field_desc: String)

case class CdcLogs(detailedlogs: String, statlogs: String)

case class StagingLocation(baseline_stg: String, daily_stg: String)

case class HandingDuplicates(continueonDuplicates: Boolean, duplicateProcessingStrategy: String)

case class Matching(CDC: Boolean, baselinefileformat: String, inputfileformat: String, cdcType: String, comparisontype: String, compareinputpath: String, archivelocation: String, keyColumns: List[String], matchColumns: List[String], outputfileformat: String, outputgenerationtype: String, baseline: String, inserts: String, updates: String, deletes: String, delta: String, duplicates: String, deleteidentifiercolumn: String, deleteflag: String, delboolean: Boolean, cdclogs: CdcLogs, stagingLocation: StagingLocation,handingDuplicates: HandingDuplicates,handleRunId:HandleRunId,fullCycle:Boolean)

/*case class Column(
                   columnName: String,
                   columnType: String,
                   columnFormat: String,
                   columnLength: Int,
                   precision: Int,
                   nullable: String,
                   defaultValue: String,
                   autoGenerate: String,
                   desc: String
                 )*/
// case class outputcolumn(columnName: String, columnType: String, columnFormat: String, columnLength: Option[Int], precision: Int, nullable: String, defaultValue: String, paddingChar: String, alignment: String, desc: String)

// case class outputProperties(outputType: String, desc: String, outputName: String, rowSeparator: String, delimeter: String, includeHeader: String, textEnclouser: String, dieOnError: String, encoding: String, outputLocation: String, outputFileName: String)

case class HandleRunId(handle:Boolean,runidColumn:String,updatedrunidColumn:String,jobrunColumn:String)

/*case class Schema(column: List[Column])

case class OutputProperties(outputType: String,schema: Schema)

case class Output(outputProperties: OutputProperties)

case class Outputs(output: Output)*/
