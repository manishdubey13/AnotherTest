package com.abc.datalake.lc.model

case class Legs(numberOfLegs : Int,legNames:Seq[String],intraLegRules:String)
case class Tolerance(toleranceField : String,tolerance:Int)
//case class Tolerances(tolerances : Seq[Tolerance])
//case class StrategyCriteria(strategyName : String,legs:Legs,matchingFields:Seq[String],nonMatchingFields : Seq[String],tolerance:Tolerances)
case class StrategyCriteria(strategyName : String,legs:Legs,matchingFields:Seq[String],nonMatchingFields : Seq[String],tolerance:Tolerance)
case class StrategyData(TradeReference : Int,tradeDate : java.sql.Date,PayReceive : String,Strike : Double ,underlyingCurrency : String,
                underlyingNotional :Int)


