package com.abc

import org.apache.spark.sql.Row

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
  * Class is for bulding logs in a organized way in a hive table
  */

class LogBuilder extends Serializable {
  val logs = new ArrayBuffer[Row] with mutable.SynchronizedBuffer[Row]
  def add(logType: String, logLevel: String, message: String) = {
    logs.append(Row(logType, logLevel,message))
  }
   val logstats = new ArrayBuffer[Row] with mutable.SynchronizedBuffer[Row]
   def logstatsadd(jobstarttime: String,jobendtime: String,basefilename :String,basefilecount:Long,dailyfilecount:Long,deltafile:Long,updatesfile:Long,deletes:Long,inserts:Long,duplicates: Long,applicationid:String): Unit ={
    logstats.append(Row(jobstarttime,jobendtime,basefilename,basefilecount,dailyfilecount,deltafile,updatesfile,deletes,inserts,duplicates,applicationid))
  }

}
