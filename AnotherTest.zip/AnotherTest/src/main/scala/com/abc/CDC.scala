package com.abc

import com.aig.datalake.lc.model.{CdcLogs, Matching, StagingLocation}
// import com.aig.lif.common.model.{CdcLogs, Matching, StagingLocation}


abstract class CDC(val m: Matching) {
  def execute()
}
