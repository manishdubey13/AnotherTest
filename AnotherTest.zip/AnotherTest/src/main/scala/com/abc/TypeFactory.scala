package com.abc

import org.apache.spark.sql.SparkSession

object TypeFactory {

  def apply(fileType: String, sparkSession: SparkSession): FileType = fileType match {
    case "avro" => new AvroFile(sparkSession)
    case "parquet" => new ParquetFile(sparkSession)
    case "csv" => new CsvFile(sparkSession)
  }
}