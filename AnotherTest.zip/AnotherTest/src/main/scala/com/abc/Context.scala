package com.abc

import net.liftweb.json._
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

/**
  * This trait is to run all sparkcode in one sparksession all the classes objects should extends this.
  */
trait Context extends Serializable{
var appname="CDC FRAMEWORK"
  lazy val sparkConf: SparkConf = new SparkConf()
    .setAppName(appname)
    .setMaster("local[*]")
     .set("spark.cores.max", "2")
    .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .set("spark.speculation","false")
    .set("spark.memory.fraction","0.75")
    .set("spark.memory.storageFraction","0.25")
   //.set("Spark.shuffle.memoryFraction","0.4")
    //.set("spark.rpc.io.serverThread","64")
    .set("spark.yarn.executor.memoryOverhead","4096")
   // .set("spark.sql.inMemoryColumnarStorage.compress","true")
    //.set("spark.sql.shuffle.partitions","2001")
    //.set("spark.sql.shuffle.partitions","200")
     .set("spark.sql.autoBroadcastJoinThreshold", "209715200")
    .set("spark.default.parallelism","10")
    //.set("spark.sql.broadcastTimeout","36000")

  lazy val sparkSession: SparkSession = SparkSession
    .builder()
    .config(sparkConf)
   .enableHiveSupport()
    .getOrCreate()

  val sc: SparkContext = sparkSession.sparkContext

  implicit val formats: DefaultFormats.type = DefaultFormats

  /**
    * aws credentials
    */
/*  sparkSession.sparkContext.hadoopConfiguration.set("fs.s3.impl","com.amazon.ws.emr.hadoop.fs.s3n2.S3NativeFileSystem2")
  sparkSession.sparkContext.hadoopConfiguration.set("fs.s3.awsAccessKeyId", "AKIAJWDA434E56SHK2JA")
  sparkSession.sparkContext.hadoopConfiguration.set("fs.s3.awsSecretAccessKey", "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")*/
}



