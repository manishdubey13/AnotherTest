package com.abc

import java.io.FileNotFoundException
import java.util

import Driver.{writeLogs, writeStatLogs}
import helper._
 import com.aig.datalake.lc.model.{Matching}
// import com.aig.lif.common.model.Matching

import tableOperations.{_dateFormat, createDfWithHashKeys, logFile, sc, sparkSession, startTime}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.sql.functions.{col, lit, _}
import org.apache.spark.sql.types._
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable.ListBuffer

class SparkCDC(override val m: Matching,val isParallel: Boolean) extends CDC(m) {
  @transient lazy val log: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)

val COLUMN_VALUE_INSERT= lit("I")
val COLUMN_VALUE_UPDATE = lit("U")
val COLUMN_VALUE_DELETE = lit("D")
val COLUMN_VALUE_UNCHANGED = lit("UN")

  val RECORD_MODIFIER = "record_modifier"
  val KEYHASH = "keyhash"
  val NON_KEYHASH = "nonkeyhash"

  val keyColumns: String = m.keyColumns.mkString(",")
  val matchColumns: String = m.matchColumns.mkString(",")

  var baselineDF: sql.DataFrame = _
  var dailyDF: sql.DataFrame = _
  var insertsOnlyDF: sql.DataFrame = _
  var updatesOnlyDF: sql.DataFrame = _
  var deletesOnlyDF: sql.DataFrame = _
  var unchangedOnlyDF: sql.DataFrame = _
  var deltaDF: sql.DataFrame = _
  var newBaselineDF: sql.DataFrame = _

  var baseDfCount: Long = 0
  var dailyDfCount: Long = 0
  var insertsCount: Long = 0
  var updatedCount: Long = 0
  var deletedCount: Long = 0
  var unchangedCount: Long = 0
  var deltaCount: Long = 0
  var newBaselineCount: Long = 0
  var duplicatecount: Long =0

  def execute(): Unit = {
    if (!validateInput()) {
      writeLogs(logFile.logs, location = m.cdclogs.detailedlogs)
      logFile.logs.clear()
      System.exit(1)
    }

    logFile.add("INFO", "INFO", "CDC Calculation Started")
    logFile.add("STATS", "INFO", "Job Completed :" + startTime.value)

    try {
      createBaseAndDailyDF("base_stg", "base_with_hashkeys", "daily_stg", "daily_with_hashKey")
      performCDC()
     writeFiles()
     countRecords()
     movebaseline()
     archiveFiles()
    } catch {

      case e: java.io.FileNotFoundException => logFile.add("EXCEPTION", "ERROR", "Exception occurred" + e.printStackTrace())
      case error: Exception => logFile.add("EXCEPTION", "ERROR", "Exception occurred" + error.printStackTrace())
        writeLogs(logFile.logs, location = m.cdclogs.detailedlogs)
        logFile.logs.clear()
        System.exit(1)
    }

    val endTime = sc.broadcast(_dateFormat.format(new java.util.Date()))
    logFile.add("STATS", "INFO", "Job Completed :" + endTime.value)
    logFile.logstatsadd(startTime.value, endTime.value, m.baseline, baseDfCount, dailyDfCount, deltaCount, updatedCount, deletedCount, insertsCount,duplicatecount,sc.applicationId.toString)

    logFile.add("INFO", "INFO", "Successfully Completed CDC")

    if (logFile.logstats.nonEmpty) {
      writeStatLogs(logFile.logstats, m.cdclogs.statlogs)
      logFile.logstats.clear()
    }

    if (logFile.logs.nonEmpty) {
      writeLogs(logFile.logs, m.cdclogs.detailedlogs)
      logFile.logs.clear()
    }

  }

  private def validateInput(): Boolean = {
    if (!isDirectoryExists(m.compareinputpath) ) {
      logFile.add("ERROR", "FILE", "Daily File not found")
      return false
    }

    if(m.fullCycle){
      val (destBucket, destKey) = getBucketKey(m.baseline)
      removeFile(destBucket + "/" + destKey, "--recursive")
    }

    if (!isDirectoryExists(m.baseline)) {
      createEmptyFile(m.compareinputpath,m.baseline,m.inputfileformat.toLowerCase,m.baselinefileformat.toLowerCase)
    }

    true
  }

  private def archiveFiles() = {
    val _dateFormatFile = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val date_ = _dateFormatFile.format(new java.util.Date())
    val splitDate = date_.split("-")
    val dateLoc = splitDate(0) + "/" + splitDate(1) + "/" + splitDate(2)

    val (archBucket, archKey) = getBucketKey(m.archivelocation)
    val (deltaBucket, deltaKey) = getBucketKey(m.delta)

    removeFile(archBucket + "/" + archKey + "/" + dateLoc, "--recursive")
    copyFile("s3://" + deltaBucket + "/" + deltaKey, archBucket + "/" + archKey + "/" + dateLoc, "--recursive")
  }


  private def createBaseAndDailyDF(stgTableBase: String, stgTableWithHashColsBase: String,
                                   stgTableDaily: String, stgTableWithHashColsDaily: String): Unit = {
    val parallelOps=List(List(m.baseline,m.baselinefileformat,stgTableBase,matchColumns,keyColumns,stgTableWithHashColsBase,m.cdclogs.detailedlogs),
      List(m.compareinputpath,m.inputfileformat,stgTableDaily,matchColumns,keyColumns,stgTableWithHashColsDaily,m.cdclogs.detailedlogs))

    val result = parallelOps.par.map(x => createDfWithHashKeys(x(0),x(1),x(2),x(3),x(4),x(5),x(6)))
    baselineDF = result(0)
    dailyDF = result(1)

    /*baselineDF = createDfWithHashKeys(m.baseline, m.baselinefileformat, stgTableBase, matchColumns,
      keyColumns, stgTableWithHashColsBase, m.cdclogs.detailedlogs, m.duplicates)

    dailyDF = createDfWithHashKeys(m.compareinputpath, m.inputfileformat, stgTableDaily, matchColumns,
      keyColumns, stgTableWithHashColsDaily, m.cdclogs.detailedlogs, m.duplicates)*/

    /*var req = List(
      (baselineDF, m.baseline, m.baselinefileformat, stgTableBase, matchColumns,
        keyColumns, stgTableWithHashColsBase, m.cdclogs.detailedlogs, m.duplicates),
      (dailyDF, m.compareinputpath, m.inputfileformat, stgTableDaily, matchColumns,
        keyColumns, stgTableWithHashColsDaily, m.cdclogs.detailedlogs, m.duplicates)
    )

    var res: Any = null

    if(isParallel) res = req.par.map(r => {r._1 = createDfWithHashKeys(r._2,r._3,r._4,r._5, r._6, r._7, r._8, r._9)})
    else res = req.map(r => createDfWithHashKeys(r._1,r._2,r._3,r._4, r._5, r._6, r._7, r._8))

    baselineDF = res(0)
    dailyDF = res(1)*/

  }

  private def deDuplicationDF(inputDF: DataFrame): DataFrame = {
    inputDF.createOrReplaceGlobalTempView("dailyDFstg")
    val _count = sparkSession.sql(
      """
          select (d.Keyhash) as KeyX,count(d.Keyhash) AS DCNT
          from global_temp.dailyDFstg d
          group by d.Keyhash having count(d.Keyhash)=1
        """)
    _count.createOrReplaceGlobalTempView("countDF")

    val uniqueDF = sparkSession.sql("select d.* from global_temp.dailyDFstg d INNER JOIN global_temp.countDF CD ON d.Keyhash=CD.KeyX").toDF()
    uniqueDF
  }

  private def selectAny(inputDF: DataFrame): DataFrame = {
    inputDF.createOrReplaceGlobalTempView("dailyDFstg")
    val selectAny = sparkSession.sql("SELECT tmp.* FROM (SELECT *,row_number() OVER (PARTITION BY Keyhash order by Keyhash) as rank FROM global_temp.dailyDFstg ) tmp WHERE rank=1").drop("rank").toDF()
    selectAny
  }

 private def createEmptyFile(_sourceFile: String, _destFile: String,inputFormat : String,outFormat : String): Unit = {
    if(inputFormat == "avro" && outFormat =="avro"){
      val df_avro = sparkSession.read
        .format("com.databricks.spark.avro")
        .load(_sourceFile)
      df_avro.createOrReplaceGlobalTempView("avro_stg")
      sparkSession.sql("select * from global_temp.avro_stg where 1=0").write.mode("overwrite").format("com.databricks.spark.avro")
        .save(_destFile)
    }   else if (inputFormat == "parquet" && outFormat =="parquet"){
      val df_parquet = sparkSession.read.parquet(_sourceFile)
      df_parquet.createOrReplaceGlobalTempView("parquet_stg")
      sparkSession.sql("select * from global_temp.parquet_stg where 1=0").write.mode("overwrite").parquet(_destFile)
    } else if(inputFormat == "avro" && outFormat =="parquet"){
      val df_avro = sparkSession.read
        .format("com.databricks.spark.avro")
        .load(_sourceFile)
      df_avro.createOrReplaceGlobalTempView("avro_stg")
      sparkSession.sql("select * from global_temp.avro_stg where 1=0").write.mode("overwrite").parquet(_destFile)
    } else{
      val df_parquet = sparkSession.read.parquet(_sourceFile)
      df_parquet.createOrReplaceGlobalTempView("parquet_stg")
      sparkSession.sql("select * from global_temp.parquet_stg where 1=0").write.mode("overwrite").format("com.databricks.spark.avro")
        .save(_destFile)
    }
  }

  /**
    * Createfiles  method will generate the invidual files(update/deletes/inserts files) and stores them on folder lcation from the json
    *
    */
  private def performCDC(): Any = {

    if (dailyDF.count() == 0 ) {
      logFile.add("INFO", "INFO", "Daily file record count is zero")
      writeLogs(logFile.logs, location = m.cdclogs.detailedlogs)
      logFile.logs.clear()
      System.exit(1)
    }

    dailyDF.createOrReplaceGlobalTempView("dailytable")
    val sqlTextDfDup = "select count(*) as record_count," + keyColumns +
      " from global_temp.dailytable group by " + keyColumns +
      " having count(*) > 1"
    val dfDuplicates = sparkSession.sql(sqlTextDfDup).toDF()
    logFile.add("QUERY", "INFO", "QUERY TO GET DUPLICATES :" + sqlTextDfDup)
    duplicatecount=dfDuplicates.select(sum(col("record_count").cast(IntegerType))).rdd.map(r => r(0)).collect()(0).asInstanceOf[Long]
    logFile.add("STATS", "INFO", "DUPLICATE RECORD COUNT :" + duplicatecount)

    if (!dfDuplicates.head(1).isEmpty) {
      if (!m.handingDuplicates.continueonDuplicates) {
        logFile.add("INFORMATION", "ERROR", "EXITING THE APPLICATION BECAUSE OF DUPLICATES")
        writeLogs(logFile.logs, location = m.cdclogs.detailedlogs)
        logFile.logs.clear()
        System.exit(1)
      }
      else {
        logFile.add("INFORMATION", "ERROR",
          "Duplicate key exists in file  hence cdc is not supported")
        log.info("Duplicate key exists in daily file  hence cdc is not supported")
        dfDuplicates.coalesce(1)
          .write.mode("overwrite").option("header", "true")
          .format("com.databricks.spark.csv").save(m.duplicates)
        m.handingDuplicates.duplicateProcessingStrategy.toLowerCase match {
          case "ignore" => dailyDF = deDuplicationDF(dailyDF)
          case "selectany" => dailyDF = selectAny(dailyDF)
          case _ => throw new RuntimeException("Not a valid duplicateProcessingStrategy: " + m.handingDuplicates.duplicateProcessingStrategy + "value is found")
        }
      }
    }

    import sparkSession.implicits._
    val fullTable = dailyDF
      .sort(KEYHASH, NON_KEYHASH)
      .alias("daily")
      .join(
        baselineDF.sort(KEYHASH, NON_KEYHASH).alias("base"),
        dailyDF(KEYHASH) === baselineDF(KEYHASH),
        "full_outer")
      .persist(StorageLevel.MEMORY_ONLY_SER)

   /* val _fullTable = dailyDF
      .alias("daily")
      .join(
        baselineDF.alias("base"),
        dailyDF(KEYHASH) === baselineDF(KEYHASH),
        "full_outer")
      .write.bucketBy(4,KEYHASH,NON_KEYHASH)
      .sortBy(KEYHASH, NON_KEYHASH)
      .mode("overwrite")
      .saveAsTable("bucketed_hash_table")

    val fullTable = sparkSession.table("bucketed_hash_table")*/


    //    val dailyFeildsString = dailyFeilds.mkString(",")

    if (m.comparisontype.toUpperCase == CdcComparisonType.FULL.toString) {

      insertsOnlyDF = fullTable
        .select("daily.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_INSERT)
        .filter("base." + KEYHASH + " is null and daily." + KEYHASH + " is not null")
        .drop(KEYHASH, NON_KEYHASH)

      deletesOnlyDF = fullTable
        .select("base.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_DELETE)
        .filter("daily." + KEYHASH + " is null")
        .drop(KEYHASH, NON_KEYHASH)

      if(m.handleRunId.handle){

        val dailyFeilds =
          dailyDF.schema.fields.map(x => "daily." + x.name).mkString(",")
            .replace("daily."+m.handleRunId.runidColumn,"base."+m.handleRunId.runidColumn)
            .replace("daily."+m.handleRunId.updatedrunidColumn,"daily."+m.handleRunId.runidColumn).split(",").toList

        updatesOnlyDF = fullTable
          .select(dailyFeilds.map(c => if (c == "daily."+m.handleRunId.runidColumn) col(c).alias(m.handleRunId.updatedrunidColumn) else col(c)): _*)
          .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UPDATE)
          .where("daily." + KEYHASH + " = base." + KEYHASH + " and daily." + NON_KEYHASH + " != base." + NON_KEYHASH)
          .drop(KEYHASH, NON_KEYHASH)
      }else{
        updatesOnlyDF = fullTable
          .select("daily.*")
          .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UPDATE)
          .where("daily." + KEYHASH + " = base." + KEYHASH + " and daily." + NON_KEYHASH + " != base." + NON_KEYHASH)
          .drop(KEYHASH, NON_KEYHASH)
      }

      unchangedOnlyDF = fullTable
        .select("base.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UNCHANGED)
        .where("daily." + KEYHASH + " = base." + KEYHASH + " and daily." + NON_KEYHASH + " = base." + NON_KEYHASH)
        .drop(KEYHASH, NON_KEYHASH)

      deltaDF = updatesOnlyDF
        .union(insertsOnlyDF)
        .union(deletesOnlyDF)


      newBaselineDF = insertsOnlyDF
        .union(updatesOnlyDF)
        .union(unchangedOnlyDF)
        .drop(RECORD_MODIFIER)


    } else if (m.comparisontype.toUpperCase == CdcComparisonType.DELTA.toString && m.delboolean) {

      insertsOnlyDF = fullTable
        .select("daily.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_INSERT)
        .filter("base." + KEYHASH + " is null and daily." + KEYHASH + " is not null")
        .drop(KEYHASH, NON_KEYHASH,m.deleteidentifiercolumn)

      if(m.deleteidentifiercolumn == RECORD_MODIFIER ) {
      deletesOnlyDF = fullTable
        .select("daily.*")
        .filter(col(m.deleteidentifiercolumn) === m.deleteflag)
        // .drop(KEYHASH, NON_KEYHASH,m.deleteidentifiercolumn)

      }
      else {
        deletesOnlyDF = fullTable
          .select("daily.*")
          .withColumn(RECORD_MODIFIER, COLUMN_VALUE_DELETE)
          .filter(col(m.deleteidentifiercolumn) === m.deleteflag)
         // .drop(KEYHASH, NON_KEYHASH, m.deleteidentifiercolumn)

      }
      val delkeyhash = deletesOnlyDF.select(KEYHASH).map(r => r.getString(0)).collect.toList
      deletesOnlyDF = deletesOnlyDF.drop(KEYHASH, NON_KEYHASH, m.deleteidentifiercolumn)

      if(m.handleRunId.handle){
        val dailyFeilds =
          dailyDF.schema.fields.map(x => "daily." + x.name).mkString(",")
            .replace("daily."+m.handleRunId.runidColumn,"base."+m.handleRunId.runidColumn)
            .replace("daily."+m.handleRunId.updatedrunidColumn,"daily."+m.handleRunId.runidColumn).split(",").toList

        updatesOnlyDF = fullTable
          .select(dailyFeilds.map(c => if (c == "daily."+m.handleRunId.runidColumn) col(c).alias(m.handleRunId.updatedrunidColumn) else col(c)): _*)
          //.select(dailyFeilds.map(c => col(c)): _*)
          .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UPDATE)
          .where("daily." + KEYHASH + " = base." + KEYHASH + " and daily." + NON_KEYHASH + " != base." + NON_KEYHASH)
          //.drop(KEYHASH, NON_KEYHASH, m.deleteidentifiercolumn)
      }else{
        updatesOnlyDF = fullTable
          .select("daily.*")
          .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UPDATE)
          .where("daily." + KEYHASH + " = base." + KEYHASH + " and daily." + NON_KEYHASH + " != base." + NON_KEYHASH)
         // .drop(KEYHASH, NON_KEYHASH, m.deleteidentifiercolumn)

      }
      val updkeyhash = updatesOnlyDF.select(KEYHASH).rdd.map(r => r(0)).collect()
      updatesOnlyDF = updatesOnlyDF.drop(KEYHASH, NON_KEYHASH, m.deleteidentifiercolumn)



      /*unchangedOnlyDF = fullTable
        .select("base.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UNCHANGED)
        .filter("daily." + KEYHASH + " is null")
        .drop(KEYHASH, NON_KEYHASH, m.deleteidentifiercolumn)*/

      val keyhashes = delkeyhash.union(updkeyhash).distinct
      unchangedOnlyDF = fullTable
        .select("base.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UNCHANGED)
        .filter(!col("base." + KEYHASH).isin(keyhashes : _*))
        .drop(KEYHASH, NON_KEYHASH, m.deleteidentifiercolumn)

      deltaDF = updatesOnlyDF
        .union(insertsOnlyDF)
        .union(deletesOnlyDF)
      newBaselineDF = insertsOnlyDF
        .union(updatesOnlyDF)
        .union(unchangedOnlyDF)
        .drop(RECORD_MODIFIER)


    } else if (m.comparisontype.toUpperCase == CdcComparisonType.DELTA.toString && !m.delboolean) {

      insertsOnlyDF = fullTable
        .select("daily.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_INSERT)
        .filter("base." + KEYHASH + " is null and daily." + KEYHASH + " is not null")
        .drop(KEYHASH, NON_KEYHASH)

      if(m.handleRunId.handle){
        /*val dailyFeilds =
          dailyDF.schema.fields.map(x => "daily." + x.name)
            .diff(List("daily."+m.handleRunId.runidColumn, "daily."+m.handleRunId.updatedrunidColumn, "daily."+m.handleRunId.jobrunColumn, "daily.nonkeyhash", "daily.keyhash")) ++
            List("base."+m.handleRunId.runidColumn, "daily."+m.handleRunId.runidColumn,"daily."+m.handleRunId.jobrunColumn, "daily.nonkeyhash", "daily.keyhash", "base.nonkeyhash", "base.keyhash")
*/
        val dailyFeilds =
          dailyDF.schema.fields.map(x => "daily." + x.name).mkString(",")
            .replace("daily."+m.handleRunId.runidColumn,"base."+m.handleRunId.runidColumn)
            .replace("daily."+m.handleRunId.updatedrunidColumn,"daily."+m.handleRunId.runidColumn).split(",").toList

        updatesOnlyDF = fullTable
          .select(dailyFeilds.map(c => if (c == "daily."+m.handleRunId.runidColumn) col(c).alias(m.handleRunId.updatedrunidColumn) else col(c)): _*)
          .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UPDATE)
          .where("daily." + KEYHASH + " = base." + KEYHASH + " and daily." + NON_KEYHASH + " != base." + NON_KEYHASH)
          .drop(KEYHASH, NON_KEYHASH)

      }else{
        updatesOnlyDF = fullTable
          .select("daily.*")
          .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UPDATE)
          .where("daily." + KEYHASH + " = base." + KEYHASH + " and daily." + NON_KEYHASH + " != base." + NON_KEYHASH)
          .drop(KEYHASH, NON_KEYHASH)

      }
      unchangedOnlyDF = fullTable
        .select("base.*")
        .withColumn(RECORD_MODIFIER, COLUMN_VALUE_UNCHANGED)
        .filter("base." + KEYHASH + " is not null and daily." + KEYHASH + " is null")
        .drop(KEYHASH, NON_KEYHASH)

      deltaDF = updatesOnlyDF.union(insertsOnlyDF)

      newBaselineDF = insertsOnlyDF
        .union(updatesOnlyDF)
        .union(unchangedOnlyDF)
        .drop(RECORD_MODIFIER)


      import org.apache.spark.sql.Row
      val  schema_string = "id"
      val schema_rdd = StructType(schema_string.split(",").map(fieldName => StructField(fieldName, StringType, true)) )

      deletesOnlyDF = sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],schema_rdd)

    } else {
      logFile.add("ERROR", "INFO", "CDC LOGIC YET TO IMPLEMENT")
    }
  }


  private def writeFile(outputType: String, writeDF: sql.DataFrame, fileName: String) = {
   /*println("debug-1" + fileName)
    val concatBuilderSelectSQL: util.ArrayList[String] = new util.ArrayList[String]()

    if(outputType == "parquet") {
      val dfschema = writeDF.schema.fields.map(x => (x.name, x.dataType)).toList

      var outputCollist = ListBuffer[(String, String)]()
      o.schema.column.foreach(x => {
        outputCollist += ((x.columnName, x.columnType.toLowerCase))
      })
      // for ((colname, coldatatype) <- dfschema) {
        for ((outcolname, outcoltype) <- outputCollist.toList) {
         // if (colname == outcolname) {
            outcoltype match {
              case "string" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as string) as " + outcolname)
              case "int" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as int) as " + outcolname)
              case "smallint" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as int) as " + outcolname)
              case "integer" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as int) as " + outcolname)
              case "long" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as long) as " + outcolname)
              case "number" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as int) as " + outcolname)
              case "double" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as double) as " + outcolname)
              case "float" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as double) as " + outcolname)
              case "boolean" => concatBuilderSelectSQL.add("CAST(" + outcolname + " as boolean) as " + outcolname)
              case "date" => concatBuilderSelectSQL.add("CAST(" + outcolname + "/1000 AS timestamp) as " + outcolname)
              case "timestamp" => concatBuilderSelectSQL.add("CAST(" + outcolname + "/1000 AS timestamp) as " + outcolname)
              case _ => concatBuilderSelectSQL.add("CAST(" + outcolname + " as string) as " + outcolname)

            }
      }
      val r = scala.util.Random
      val sqlconcatStatement = StringUtils.join(concatBuilderSelectSQL, ",")
      val temptableName ="temp_writedf" + r.nextInt(1000000000)
      println(temptableName)
      writeDF.createOrReplaceGlobalTempView(temptableName)
      val sqlText = "select " + sqlconcatStatement + " from global_temp."+ temptableName
      val writeDF1 = sparkSession.sql(sqlText).toDF()
      TypeFactory(outputType, sparkSession).writeFile(writeDF1, fileName)
    }
    else {*/
      TypeFactory(outputType, sparkSession).writeFile(writeDF, fileName)
      true

  }

  private def writeFiles(): Unit = {
    /*TypeFactory(m.outputfileformat, sparkSession).writeFile(insertsOnlyDF, m.inserts)
    TypeFactory(m.outputfileformat, sparkSession).writeFile(updatesOnlyDF, m.updates)
    if (deletesOnlyDF != null)
      TypeFactory(m.outputfileformat, sparkSession).writeFile(deletesOnlyDF, m.deletes)
    TypeFactory(m.outputfileformat, sparkSession).writeFile(deltaDF, m.delta)
    TypeFactory(m.outputfileformat, sparkSession).writeFile(newBaselineDF, m.baseline)
    */

   if( deltaDF.count != 0) {
     val listFiles = List(
       (m.outputfileformat, insertsOnlyDF, m.inserts),
       (m.outputfileformat, updatesOnlyDF, m.updates),
       (m.outputfileformat, deletesOnlyDF, m.deletes),
       (m.outputfileformat, deltaDF, m.delta),
       (m.baselinefileformat, newBaselineDF, m.stagingLocation.baseline_stg))

     val onlyBaseAndDeltaFiles = List(
       (m.outputfileformat, deltaDF, m.delta),
       (m.baselinefileformat, newBaselineDF, m.stagingLocation.baseline_stg))

     m.outputgenerationtype match {
       case "All files" => listFiles.par.map(x => writeFile(x._1, x._2, x._3))
       case "onlyBaseAndDelta" => onlyBaseAndDeltaFiles.par.map(x => writeFile(x._1, x._2, x._3))
       case _ => throw new RuntimeException("Not a valid outputgenerationtype value is found")
     }
   } else {
     return
   }
  }

  private def movebaseline() :Unit={
    if(deltaDF.count != 0) {
      val (destBucket, destKey) = getBucketKey(m.baseline)
      println(m.baseline)
      val (stgBucket, stgKey) = getBucketKey(m.stagingLocation.baseline_stg)
      println(m.stagingLocation.baseline_stg)
      removeFile(destBucket + "/" + destKey, "--recursive")
      moveFile("s3://" + stgBucket + "/" + stgKey, destBucket + "/" + destKey, "--recursive")
    } else {
      return
    }
  }

  private def countRecords(): Unit = {

    val listCounts = List(baselineDF, dailyDF, insertsOnlyDF, updatesOnlyDF,
      deletesOnlyDF, unchangedOnlyDF, deltaDF, newBaselineDF)

    val result = listCounts.par.map(_.count())

    baseDfCount = result.head
    dailyDfCount = result(1)
    insertsCount = result(2)
    updatedCount = result(3)
    deletedCount = result(4)
    unchangedCount = result(5)
    deltaCount = result(6)
    newBaselineCount = result(7)

    logFile.add("STATS", "INFO", "Base file record count:" + baseDfCount)
    logFile.add("STATS", "INFO", "Daily file record count :" + dailyDfCount)
    logFile.add("STATS", "INFO", "Insert record count :" + insertsCount)
    logFile.add("STATS", "INFO", "Updated record count :" + updatedCount)
    logFile.add("STATS", "INFO", "Deleted record count : " + deletedCount)
    logFile.add("STATS", "INFO", "Unchanged record count : " + unchangedCount)
    logFile.add("STATS", "INFO", "Delta record count :" + deltaCount)
    logFile.add("STATS", "INFO", "New Baseline record count:" + newBaselineCount)
  }
}


