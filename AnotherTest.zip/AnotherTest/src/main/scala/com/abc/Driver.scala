package com.abc

import helper._
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StructField, StructType, _}
import sparkSession.implicits._
import tableOperations.{startTime,logFile}

import scala.collection.mutable.ArrayBuffer


object Driver extends Context {

  def main(args: Array[String]) {

    // System.setProperty("hadoop.home.dir", "C:\\Tools\\winutils")
        Logger.getLogger("org").setLevel(Level.ERROR)
      Logger.getLogger("akka").setLevel(Level.ERROR)
      if (args.length < 1) {
        System.err.println("Usage: CDC driver accepts one arguments <path_to_json_file>")
        System.exit(1)
      }

      val pathToJson = args(0).toString
     /* if(isDirectoryExists(pathToJson) == false){
        println("Json path does not exist")
        System.exit(1)
      }*/
  //   val cdcInfo = com.aig.lif.common.helper.getCDCFieldsFromJson(pathToJson)
     val cdcInfo = getCDCFieldsFromJson(pathToJson)
     // val outputProperties = getoutputPropertiesFromJson(pathToJson)

      val cdc: CDC = new SparkCDC(cdcInfo,false)
      cdc.execute()

  }

  /**
    * This method is to write logs to a location
    *
    * @param _logs    : ArrayBuffer
    * @param location : Logs will be savec in the specified location
    */

  def writeLogs(_logs: ArrayBuffer[Row], location: String): Unit = {
    //TODO - move logSchema to static var at top
    import org.apache.spark.sql.functions.lit
    val logSchema = StructType(Seq(
      StructField("logtype", StringType, nullable = true),
      StructField("loglevel", StringType, nullable = true),
      StructField("log", StringType, nullable = true)))

    val logRowRDD = sc.parallelize(_logs)

    val logdf = sparkSession.createDataFrame(logRowRDD, logSchema)
    logdf.select($"logtype", $"loglevel", $"log").withColumn("jobstarttime",lit(startTime.value)).withColumn("Spark_AppId", lit(sc.applicationId)).coalesce(1).write.mode("append").format("com.databricks.spark.csv").option("delimiter", "|").save(location)

  }

  /**
    * This to write the stats information of the job
    *
    * @param _logStats desc
    * @param location  desc
    */
  def writeStatLogs(_logStats: ArrayBuffer[Row], location: String): Unit = {

    val statsSchema = StructType(Seq(
      StructField("jobstarttime", StringType, nullable = true),
      StructField("jobendtime", StringType, nullable = true),
      StructField("filename", StringType, nullable = true),
      StructField("basefilecount", LongType, nullable = true),
      StructField("dailyfilecount", LongType, nullable = true),
      StructField("deltafile", LongType, nullable = true),
      StructField("updatesfile", LongType, nullable = true),
      StructField("deletes", LongType, nullable = true),
      StructField("inserts", LongType, nullable = true),
      StructField("duplicates", LongType, nullable = true),
      StructField("applicationid", StringType, nullable = true)
    ))

    val logStatsRDD = sc.parallelize(_logStats)
    sparkSession.createDataFrame(logStatsRDD, statsSchema).coalesce(1).write.mode("append").format("com.databricks.spark.csv").save(location)
  }
}