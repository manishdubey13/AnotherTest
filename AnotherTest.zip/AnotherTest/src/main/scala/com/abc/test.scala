package com.abc

import helper._
import java.io.{File, FileNotFoundException}
import java.util

import Driver.sparkSession
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.types.{IntegerType, StructField}
import org.apache.spark.sql.types._
import org.apache.log4j.{Level, Logger}
import org.apache.hadoop.fs._
import org.apache.hadoop._
import com.databricks.spark.avro
import org.apache.spark.{SparkConf, SparkContext}
import helper._
import org.apache.hadoop.conf.Configuration
// import org.apache.hadoop.fs.s3native
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.{Failure, Success}
import scala.util.Random



import scala.util.Try
import scala.util.{Success, Failure}
import sparkSession.implicits._
import org.apache.hadoop.fs.{FileSystem, _}

import scala.io.Source

import scala.sys.process._

import org.json4s.jackson.JsonMethods.parse
import org.json4s.{DefaultFormats, _}

import scala.collection.mutable.ListBuffer
object test extends Context {
/*
  def main(args: Array[String]): Unit = {
    val cdcInfo = getCDCFieldsFromJson("src\\main\\resources\\sample_json.json")
    val o = getoutputPropertiesFromJson("src\\main\\resources\\sample_json.json")
    import scala.collection.mutable.ListBuffer

    val concatBuilderSelectSQL: util.ArrayList[String] = new util.ArrayList[String]()

    import org.apache.commons.lang3.StringUtils

    var outputCollist = ListBuffer[(String, String)]()
    o.schema.column.foreach(x => {
      outputCollist += ((x.columnName, x.columnType.toLowerCase))
    })

      for ((outcolname, outcoltype) <- outputCollist.toList) {

        // if (colname == outcolname) {
        outcoltype match {

          case "string" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as string")
          case "int" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as int")
          case "smallint" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as int")
          case "integer" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as int")
          case "long" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as long")
          case "number" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as int")
          case "double" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as double")
          case "float" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as double")
          case "boolean" => concatBuilderSelectSQL.add("CAST(" + outcolname + "as boolean")
          case "date" => concatBuilderSelectSQL.add("CAST(" + outcolname + "/1000 AS timestamp)")
          case "timestamp" => concatBuilderSelectSQL.add("CAST(" + outcolname + "/1000 AS timestamp)")
          case _ => concatBuilderSelectSQL.add("CAST(" + outcolname + "as string")

            val sqlconcatStatement = StringUtils.join(concatBuilderSelectSQL, ",")
            println(sqlconcatStatement)
          //  writeDF.select(sqlconcatStatement).write.parquet(fileName)
        }

       //  val writeDF = Seq(("1234", "gsdfkjhsdf"), ("12345", "hfkjghkdf")).toDF("agent_contract_id", "producer_party_id")



    }
  }*/
}
