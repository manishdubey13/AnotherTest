package com.abc

import org.apache.spark.sql.{DataFrame, SparkSession}

trait FileType {

  def readFile(filename: String): DataFrame

  def writeFile(df: DataFrame, filename: String)

  def createEmptyFile(_sourceFile: String, _destFile: String)
}


class AvroFile(sparkSession: SparkSession) extends FileType {
  override def readFile(filename: String): DataFrame = {

    val df = sparkSession.read
      .format("com.databricks.spark.avro")
      .load(filename)
    df
  }

  override def writeFile(df: DataFrame, filename: String): Unit = {

    df.repartition(5).write.format("com.databricks.spark.avro").mode("overwrite").save(filename)
    // df.repartition(1).write.format("com.databricks.spark.avro").save(filename)
  }

  override def createEmptyFile(_sourceFile: String, _destFile: String): Unit = {
    val df_avro = sparkSession.read
      .format("com.databricks.spark.avro")
      .load(_sourceFile)
    df_avro.createOrReplaceGlobalTempView("avro_stg")
    sparkSession.sql("select * from global_temp.avro_stg where 1=0").write.mode("overwrite").format("com.databricks.spark.avro")
      .save(_destFile)
  }
}

class ParquetFile(sparkSession: SparkSession) extends FileType {
  override def readFile(filename: String): DataFrame = {

    val df = sparkSession.read
      .parquet(filename)
    df
  }

  override def writeFile(df: DataFrame, filename: String): Unit = {
    df.repartition(5).write.mode("overwrite").parquet(filename)
  }

  override def createEmptyFile(_sourceFile: String, _destFile: String): Unit = {
    val df_parquet = sparkSession.read.parquet(_sourceFile)
    df_parquet.createOrReplaceGlobalTempView("parquet_stg")
    sparkSession.sql("select * from global_temp.parquet_stg where 1=0").write.mode("overwrite").parquet(_destFile)
  }
}

class CsvFile(sparkSession: SparkSession) extends FileType {
  override def readFile(filename: String): DataFrame = {

    val df = sparkSession.read.format("csv").option("header", "true").option("inferschema", "true").load(filename)
    df
  }

  override def writeFile(df: DataFrame, filename: String): Unit = {
    System.out.println("Writing File: " + filename)
    df.repartition(1).write.format("csv").option("header", "true").mode("overwrite").save(filename)
  }

  override def createEmptyFile(_sourceFile: String, _destFile: String): Unit = {
    val df_csv = sparkSession.read.csv(_sourceFile)
    df_csv.createOrReplaceGlobalTempView("csv_stg")
    sparkSession.sql("select * from global_temp.csv_stg where 1=0").write.mode("overwrite").csv(_destFile)
  }

}
