package com.abc

import java.sql.Date
import java.text.SimpleDateFormat
import java.time.LocalDate

import scala.io.Source
import com.aig.datalake.lc.model._
import org.apache.spark.sql.Encoders

import scala.collection.mutable


object StfDriver extends Context
{
  //implicit val formats: DefaultFormats.type = DefaultFormats
  import sparkSession.implicits._
  private val fullDate = new SimpleDateFormat("MM/dd/yyyy")
  def parseDate(datestring: String): java.sql.Date =
  {
   val d = fullDate.parse(datestring);
    new Date(d.getTime)
  }

  implicit def ordered: Ordering[java.sql.Date] = new Ordering[java.sql.Date] {
    def compare(x: java.sql.Date, y: java.sql.Date): Int = x compareTo y
  }
  def main(args: Array[String]): Unit =
  {

    val stfCriteria = args(0).toString

    val json = Source.fromFile(stfCriteria)
    val parsedJson = net.liftweb.json.parse(json.mkString)
    val criteria = (parsedJson \\ "strategyCriteria").extract[StrategyCriteria]
    criteria
    criteria.matchingFields.foreach(println(_) )
   println(criteria)

    val df = TypeFactory("csv", sparkSession).readFile("/Users/manish/sparkproject/cdcframework_revamped/src/main/resources/daily/stf-Input.csv")
    df.createOrReplaceGlobalTempView("StrategyFinder")

    println("I'm " + df.getClass)
    df.foreach(println(_))

    val allColumns = df.schema.fields.map(x => x.name).toList.mkString(",")
    val colDataTypes = df.schema.fields.map(x => (x.name, x.dataType)).toList

    println(allColumns)
    println(colDataTypes)


    val stgDF = sparkSession.sql("select TRADE_REFERENCE,TRADE_DATE,PAY_RECEIVE,STRIKE ,UNDERLYINGCURRENCY,UNDERLYINGNOTIONAL from global_temp.StrategyFinder").toDF()

  // val data = Encoders.bean(StrategyData.getClass)

    println(stgDF.getClass)
   //val d = stgDF.as (data)
    stgDF.schema.printTreeString()


    //d.schema.printTreeString()

    // val data = stgDF.map(row =>StrategyData(row.getInt(0),parseDate(row.getString(1)),row.getString(2),row.getDouble(3),row.getString(4),row.getInt(5)))
     val data = stgDF.map(row =>StrategyData(row.getInt(0),parseDate(row.getString(1)),row.getString(2),row.getDouble(3),row.getString(4),row.getInt(5)))

     //data.groupBy(criteria.matchingFields(0)).count().show()
/*
    val initialSet = mutable.HashSet.empty[(StrategyData, StrategyData)]
    val addToSet = (s: mutable.HashSet[(StrategyData, StrategyData)], v: (StrategyData, StrategyData)) => s += v
    val mergePartitionSets = (p1: mutable.HashSet[(StrategyData, StrategyData)],
                              p2: mutable.HashSet[(StrategyData, StrategyData)]) => p1 ++= p2
    val pair = data.map(x =>(x.tradeDate,x)).rdd.reduceByKeyLocally((s1,s2)=>s1+s2)
    val uniqueByKey = pair.aggregateByKey(initialSet)(addToSet, mergePartitionSets)
    */
/*    val pair = data.map(x =>(x.tradeDate,x)).rdd.groupByKey
    val allKey =   pair.keys
    val allValues =   pair.values

   // allKey.foreach(println(_))
    //allValues.foreach(println(_))
    pair.foreach(println(_))*/

    //val pair = data.map(x =>(x.tradeDate,x)).rdd.groupByKey.mapValues(_.toList)
    //val pair = data.map(x =>(x.tradeDate,x)).rdd.groupByKey.mapValues(_.toList).mapValues(_.filter(s=>s.PayReceive!="Receive"))
    val pair = data.map(x =>(x.tradeDate,x)).rdd.groupByKey.mapValues(_.toList)
    pair.foreach(println(_))


    //println(data.sh)

     // val pair = data.map(x =>(x.tradeDate,x)).rdd.groupByKey.collect()
     // val pair = data.map(x =>(x.tradeDate,x)).collect()
      //val pair = data.select()
      //pair.select("*").foreach(x=>println(x))



      //val d = pair.
      //val d1= pair.



   // d1.foreach(println(_))



   /* println()
    println("********************")
    stgDF.foreach(println(_))
    println("********************")
*/
    println("XXXXXX")
  }


}
