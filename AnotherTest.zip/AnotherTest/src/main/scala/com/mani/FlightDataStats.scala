package com.mani


import java.time.{LocalDate, LocalTime}

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.joda.time.format.DateTimeFormat

object FlightDataStats extends App
{

  val appName="FlightDataStats"
  lazy val conf = new SparkConf().setAppName(appName).setMaster("local[*]")
  lazy val session = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

  val sc  = session.sparkContext


  val airlines = sc.textFile("file:///Users/manish/spark/FlightsData/airlines.csv")
  val flightData = sc.textFile("file:///Users/manish/spark/FlightsData/flights.csv")
  val airPort = sc.textFile("file:///Users/manish/spark/FlightsData/airports.csv")


  //println(airlines.count())
   val flightParsed= flightData.map(parse)
  //flightParsed.persist()
  //flightParsed.collect().foreach(s =>println(s))
  val flightCount = flightParsed.count()

  val flightTotalDistance= flightData.map(parse).map(_.distance).reduce((x,y)=>x+y)

  val avg = flightTotalDistance/flightCount

 // println(flightTotalDistance.toString)

  println(s" Flight Avg Distance $avg")

  val anothetAvg = flightParsed.map(_.distance).aggregate((0.0,0))((acc,value) => (acc._1 + value, acc._2+1),
                (acc1,acc2) =>(acc1._1+acc2._1,acc1._2+acc2._2))

  val totalDis= anothetAvg._1
  val ct = anothetAvg._2
  println(s" Flight Avg Distance " + (totalDis/ct).toDouble)

  /* % of flight with delays */

  val flighWithDelays = flightParsed.filter(_.dep_delay>0).count().toDouble

  val flighDelayPercent = flighWithDelays/flightParsed.count.toDouble

    println(s"Flight with delays $flighDelayPercent" )

  /* flight delays by hours*/

  val delaysByHour = flightParsed.map(x=> (x.dep_delay/60).toInt).countByValue()

  delaysByHour.foreach(x=> println(x._1,x._2))

  flightParsed.unpersist()

  case class Flight(date:org.joda.time.LocalDate,airline:String,flightNum:String,origin:String,dest:String,dep: org.joda.time.LocalTime
                   ,dep_delay:Double,arrival:org.joda.time.LocalTime,airival_delay:Double,airTime:Double,distance:Double)

  def parse(row:String) :Flight=
  {

    val fields = row.split(",")

    val dateFormat = DateTimeFormat.forPattern("YYYY-mm-dd")
    val timeFormat = DateTimeFormat.forPattern("HHmm")

    val date = dateFormat.parseDateTime(fields(0)).toLocalDate
    val airline= fields(1)
    val flightNum = fields(2)
    val origin = fields(3)
    val dest = fields(4)

    val dep = timeFormat.parseDateTime(fields(5)).toLocalTime

    val dep_delay = fields(6).toDouble

    val arrival = timeFormat.parseDateTime(fields(7)).toLocalTime
    val airival_delay = fields(8).toDouble

    val airTime = fields(9).toDouble
    val distance = fields(10).toDouble

    Flight(date,airline,flightNum,origin,dest,dep,dep_delay,arrival,airival_delay,airTime,distance)

  }
}
