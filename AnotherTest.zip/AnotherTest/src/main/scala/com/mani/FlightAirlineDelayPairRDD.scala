package com.mani

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.joda.time.format.DateTimeFormat

object FlightAirlineDelayPairRDD extends App
{

  val appName = "PairRDDExample"
  lazy val conf = new SparkConf().setAppName(appName).setMaster("local[*]")
  lazy val session = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

  lazy val context = session.sparkContext


  //val airlines = context.textFile("file:///Users/manish/spark/FlightsData/airlines.csv")
  val flightData = context.textFile("file:///Users/manish/spark/FlightsData/flights.csv")
  val airPort = context.textFile("file:///Users/manish/spark/FlightsData/airports.csv")



  val parsedFligtData = flightData.map(parse)

  val parsedAirportData = airPort.filter(notHeader).map(parseAirport)

  val airportDelays = parsedFligtData.map(f =>(f.origin,f.dep_delay) )

  val byAirportDelay = airportDelays.reduceByKey((f1,f2)=>f1+f2)
  val countByAirport = airportDelays.mapValues(x =>1).reduceByKey((f1,f2) =>f1 + f2)

  val avgDelayByAirport = byAirportDelay.join(countByAirport).mapValues(f =>f._1/f._2.toDouble)

  val avgDelayByAirportCombineByKey = airportDelays.combineByKey(value =>(value,1),
    (acc:(Double,Int),value) =>(acc._1 +value,acc._2+1),
    (acc1:(Double,Int),acc2:(Double,Int)) =>(acc1._1+acc2._1,acc1._2+acc2._2)).mapValues(f=>f._1/f._2.toDouble)

  //byAirportDelay.filter(x => x._1.startsWith("J")).sortByKey(true).take(10).foreach(x =>println(x._1 + " " + x._2))
  //countByAirport.filter(x => x._1.startsWith("J")).sortByKey(true).take(10).foreach(x =>println(x._1 + " " + x._2))
  //avgDelayByAirport.filter(x => x._1.startsWith("J")).sortByKey(true).take(10).foreach(x =>println(x._1 + " " + x._2))
  //fligtDataByAirportDelay.values.take(10).foreach(print(_ ))
  //avgDelayByAirportCombineByKey.filter(x => x._1.startsWith("J")).sortByKey(true).take(10).foreach(x =>println(x._1 + " " + x._2))


  val  airportNameDescription = parsedAirportData.map(a =>(a.code,a.name)).collectAsMap()

  val airportBC = context.broadcast(airportNameDescription)

/*
  val avgDelayByAirportDescription = avgDelayByAirportCombineByKey.join(airportNameDescription).
    mapValues(x =>x._1.toString.concat(" : " +x._2))
*/
  val avgDelayByAirportDescription = avgDelayByAirportCombineByKey.map(x =>(airportBC.value(x._1),x._2))

     // avgDelayByAirportDescription.take(10).foreach(x =>println(x._1 + " " + x._2))
     avgDelayByAirportDescription.take(10).foreach(x =>println(x._1 + " : ----> " + x._2))

  case class Flight(date:org.joda.time.LocalDate,airline:String,flightNum:String,origin:String,dest:String,dep: org.joda.time.LocalTime
                    ,dep_delay:Double,arrival:org.joda.time.LocalTime,airival_delay:Double,airTime:Double,distance:Double)

  case class Airport(code:String,name:String )


  def parse(row:String) :Flight=
  {

    val fields = row.split(",")

    val dateFormat = DateTimeFormat.forPattern("YYYY-mm-dd")
    val timeFormat = DateTimeFormat.forPattern("HHmm")

    val date = dateFormat.parseDateTime(fields(0)).toLocalDate
    val airline= fields(1)
    val flightNum = fields(2)
    val origin = fields(3)
    val dest = fields(4)

    val dep = timeFormat.parseDateTime(fields(5)).toLocalTime

    val dep_delay = fields(6).toDouble

    val arrival = timeFormat.parseDateTime(fields(7)).toLocalTime
    val airival_delay = fields(8).toDouble

    val airTime = fields(9).toDouble
    val distance = fields(10).toDouble

    Flight(date,airline,flightNum,origin,dest,dep,dep_delay,arrival,airival_delay,airTime,distance)

  }

  def notHeader(row:String):Boolean=
  {
    !row.contains("Description")
  }

  def parseAirport(row:String) : Airport=
  {
    val fields = row.replace("\"","") .split(",")
    val code = fields(0)
    val name = fields(1)

    Airport(code,name)
  }


}
