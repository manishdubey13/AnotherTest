package com.mani

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object AccumulatorExample extends App
{

  val appName = "AccumulatorExample"

  lazy val conf = new SparkConf().setAppName(appName).setMaster("local[*]")
  lazy val session = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

  val sc = session.sparkContext

  val file = sc.textFile("file:///Users/manish/spark/logdata/logFile.log")

 val errorCount = sc.longAccumulator

  //file.map(processLog).saveAsTextFile("file:///Users/manish/spark/logdata/processedlogFile.log")
 val processedFile = file.map(processLog).filter(_!=None).map(s=>s.getOrElse(""))
  processedFile.saveAsTextFile("file:///Users/manish/spark/logdata/processedlogFile7.log")

  println( s" Total error found =====> ${errorCount.value}")

  def processLog(row :String) :Option[String]=
  {

    if (row.contains("ERROR")|| row.contains("error")||row.contains("Error"))
      {
        errorCount.add(1)
        Option(row)
      }
    else None
  }
}
