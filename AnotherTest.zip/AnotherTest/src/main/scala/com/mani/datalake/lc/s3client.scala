package com.mani.datalake.lc

/*import java.net.URI

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.conf.Configuration
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.AmazonServiceException
import java.io.File

import com.aig.amazon.common.util.AmazonS3Utils
import jodd.io.FileUtil*/

object s3client {

}/*
//  val s3  = AmazonS3ClientBuilder.defaultClient()
  val s3utils = new AmazonS3Utils(AmazonS3ClientBuilder.defaultClient())

 def copyObjects(bucketName: String,sourceKey : String ,DestinationKey:String,mode: Boolean): Unit = {

      s3utils.copy(bucketName, sourceKey, bucketName,DestinationKey, mode)

  }

  def moveObjects(sourceBucket: String,sourceKey: String,destinationBucket: String,destinationKey: String,mode: Boolean): Unit={

        s3utils.move(sourceBucket,sourceKey,destinationBucket,destinationKey,mode)

  }
/*
  def main(args: Array[String]): Unit = {

    try {
      s3utils.move(bucketName, sourceKey, bucketName,destinationKey, true)
    }
    catch {
      case e: CopyFailedException =>  e.printStackTrace()
    }

  }
*/
*/