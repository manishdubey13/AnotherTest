package com.mani

import org.apache.spark.{HashPartitioner, SparkConf}
import org.apache.spark.sql.SparkSession

object GooglePageRank extends App
{

  val appName = "GooglePageRank"
  lazy val conf = new SparkConf().setAppName(appName).setMaster("local[*]")
  lazy val session = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

  val sc = session.sparkContext

  val it =3

  //load the pagerank file,parse it

  val pageRankFile = sc.textFile("file:///Users/manish/spark/pagerank/web-Google.txt")

  val pageRankRDD = pageRankFile.filter(!_.contains("#")).map(_.split("\t")).map(x=>(x(0),x(1)))

  //pageRankRDD.take(10).foreach(x=> println(s" FromNodeId : ${x._1}  ToNodeId : ${x._2} "))

  val webLink = pageRankRDD.partitionBy(new HashPartitioner(100)).cache()
  //val webLink = pageRankRDD.cache()

  var rank = webLink.mapValues(r =>1.0) //give all the links default page-rank

  //rank.take(10).foreach(x=> println(s" FromNodeId : ${x._1}  rank : ${x._2} "))

 for(i<- 1 to it)
  {
    val contributionInRankRDD = webLink.join(rank).values.flatMap{case (toNodes,rank) =>
      val size = toNodes.size
      toNodes.map(toNodes =>(toNodes.toString,rank/size))
    }
   rank = contributionInRankRDD.reduceByKey(_ +_ ).mapValues(0.15+0.85 *_)
  }

  //val contributionInRankRDDKey = webLink.join(rank).keys

  //rank.take(10).foreach(x=> println(s" ToNode : ${x._1}  Rank : ${x._2}  " ))
  //contributionInRankRDD.take(10).foreach(x=> println(s"  FromNodeId: ${x._1}   " ))

 // rank.map(x=>x._1 + " " + x._2).saveAsTextFile("file:///Users/manish/spark/pagerank/web-Google-Result3.txt")
  //rank.map(x=>x._1 + " " + x._2).repartition(1).saveAsTextFile("file:///Users/manish/spark/pagerank/web-Google-Result4.txt")
 // rank.map(x=>x._1 + " " + x._2).coalesce(1, shuffle = true).saveAsTextFile("file:///Users/manish/spark/pagerank/web-Google-Result5.txt")
  rank.map(x=>x._1 + " " + x._2).coalesce(1, shuffle = true).repartition(1)
    .saveAsTextFile("file:///Users/manish/spark/pagerank/web-Google-Result7.txt")



}
