package com

package object mani
{

}
