package com.mani.scala

object ListCreationExamples extends App
{

  val weekDays = "Mon" ::"Tues" :: "Wed":: "Thur" :: "Fri" ::Nil
  val weekEndDays = List ("Sat","Sun")

  val numDays = List(1,2,3,4,5,6,7)

  val days = weekDays:::weekEndDays

  val listDays = days.zip(numDays)

  val allDays = List(weekEndDays,weekDays).flatten

  //days.foreach(println)
  //listDays.foreach(println)

  //allDays.foreach(println)

  //days.drop(1).foreach(println)

   val (l1,l2)  = days.splitAt(2)

   /* l1.foreach(println)
    println("**********")
    l2.foreach(println)

     println( numDays.sum)
  */
  //-----------------Reduce functions ..

  val nums = List(10,20,30,40,50,60)

  val numsScanRight = nums.scanRight(10)(_-_)
  val numsFoldRight = nums.foldRight(10)(_-_)
  val numsReduceRight = nums.reduceRight(_-_)

  numsScanRight.foreach(println(_))
  println("*******")
  println(numsFoldRight)
  println(numsReduceRight)




}
