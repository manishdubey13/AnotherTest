package com.mani.scala

import collection.immutable.Map
import collection.mutable.Buffer

object SetsMaps extends App
{

  val map = Map(("NY", "New York"), ("NJ", "Trenton"), "CA" -> "San Francisco")

  //map.foreach((x :(String,String) )=> println(x._1 + " " + x._2))

  val keys = map.keySet.toList
  val values = map.values.toList

  // keys.foreach(println(_))
  //values.foreach(println(_))

  val convertBackToMap = (keys zip values).toMap

  convertBackToMap.foreach((x:(String,String)) => println(x._1 + " " + x._2))
  //convertBackToMap.toList.foreach(println(_))
  //convertBackToMap.
  //convertBackToMap.flatten.foreach(println(_))

   val arry = Array(2,3,4,5,6)
   val a = new Array[String](5)

  //arry.foreach(print)
  a.foreach(println)

}