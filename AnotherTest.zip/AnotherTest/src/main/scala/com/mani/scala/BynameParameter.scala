package com.mani.scala

object BynameParameter extends App
{

  def greetings(name: String,g : =>(String)=>String)=
  {
    //println(name)
    println("name")
   println( g(name))
   println( g(name))
    //g

  }
  def greetings1(name: String,g : (String)=>String)=
  {
    //println(name)
    println("name")
    println( g(name))
    println( g(name))
    //g

  }
  def greet (g : String): String=
  {
    println("Check the calls")
    g+" Hello"
  }
  //println(greetings("Manish",_ + " "+"Hello"))
  println(greetings("Manish",greet)) ////byName Parameter lazily evaluated but eagerly evaluated on each reference
  //  call to that parameter.
  println(greetings1("Manish",greet)) //

  //println(greetings("Manish",greet))


}
