package com.mani.scala.recipes
/*
import java.util.{List => JList, LinkedList => JLinkedList}
import scala.collection.JavaConverters._
val mySList2  = myJlist.asScala
collection.mutable.Buffer[String] = Buffer("a", "b")
 val myJlist2 = mySList.asJava
myJlist2: java.util.List[String] = SeqWrapper(List("a", "b"))
* */
import java.util.concurrent.ArrayBlockingQueue
import java.util.{LinkedList => JLinkedList, List => JList}

import scala.collection.JavaConverters._
object JavaCollectionInterOperation extends App
{

  val myJlist : JList[String] = new JLinkedList[String]
  myJlist.add("a")
  myJlist.add("b")

  println(myJlist)

  val mySList : List[String]=List[String]("a","b")
  println(mySList)

  val mySList2  = myJlist.asScala //when Java list converted into Buffer which is
  // equivalent to Java List and is mutable

  println(mySList2)
  //mySList2.add("c")
  mySList2 +="c"
  println(mySList2)
  println(myJlist)

  val myJlist2 = mySList.asJava
  //myJlist2.add("d")

  val myQueue = new ArrayBlockingQueue[String](5)

  myQueue.put("a")
  myQueue.put("b")

  println(" My Queue " + myQueue)
  myQueue.take()
  println(" My Queue " + myQueue)



}
