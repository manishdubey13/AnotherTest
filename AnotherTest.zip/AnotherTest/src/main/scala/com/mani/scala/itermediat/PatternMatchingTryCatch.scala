package com.mani.scala.itermediat

import scala.util.control.NonFatal

object PatternMatchingTryCatch extends App
{

  case class Animal(name:String,age :Int)
  case class AnimaltoOldException (name:String,age : Int) extends Exception(s"$name is too old @ $age for dance")

  def makeAnimalDance(animal: Animal) :String =
  {
    if (animal.age >25)
    {
      //throw new Exception(s"${animal.name} is too old @ ${animal.age} for dance")
      //makeAnimalDance(animal) //this will run continuously, scala is optimizing the tail recursion
       s" now this is not tail Recursion" + makeAnimalDance(animal) //this will throw ava.lang.StackOverflowError and bubble up
    }else if (animal.age >18)
    {
      throw new AnimaltoOldException(animal.name,animal.age)
    }else
    {
      s" lets dance ${animal.name}"
    }
  }

  println(makeAnimalDance(Animal("Bob",12)))
 val dance  = try
 {
    //makeAnimalDance(Animal("Bob",19))
    makeAnimalDance(Animal("Bob",26))
 }catch
 {
   case AnimaltoOldException(name,age) => s"$name is too old to dance @ $age but we let him dance."
   case exception : Exception  if NonFatal(exception) =>  "something went wrong!!!"
   //if fatal exception like StackOverFlow error let it bubble up

 }

  println( s"$dance")
}
