package com.mani.scala.itermediat

object PatternMatchin
{

  def describeAge(age : Option[Int]) :String ={
    age match {
      case None => "we don't knwo your age"
      case Some(age) if age <10 => s"you are young $age year old"
      case Some(age) if age < 25 => s"you are young $age still learning "
      case Some(age) => s"you are s mature $age year old"
    }
  }
  val person :(String,Option[Int])=("manish",Some(42))
  person match {
    case (name,age) => s"$name is ${age.getOrElse(0)+2} old"
  }

  def describePerson(person : (String, Option[Int])): String=
  {
    person match
    {
      case (name,None) => s"Don not know $name Age."
      case (name,Some(age)) if age <10 => s" $name is young $age and learning fast. "
      case (name,Some(age)) if age <25 => s" $name is young $age and still learning. "
      case (name,Some(age)) => s" $name is mature $age and loves learning new things. "
    }

  }

  describePerson("manish",Some(42))
  describePerson("Akash",Some(12))
  describePerson("Aarushi",Some(6))
}
