package com.mani.scala

object TryExample extends App
{
  val states = Map("CA" -> "California","NJ" ->"New Jersey")

  //val stateName = util.Try(states("pwr"))
  val stateName = util.Try(states("NJ"))

 val state = stateName match
  {
    case util.Success(name) => name
    case util.Failure(error) => "No Such states"
  }

  print(state)
}
