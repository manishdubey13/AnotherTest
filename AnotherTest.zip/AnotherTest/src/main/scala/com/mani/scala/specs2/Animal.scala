package com.mani.scala.specs2

case class Animal(name : String , age : Int,species : Species)

