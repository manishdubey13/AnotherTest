package com.mani.scala.oops

object SelfTypeExample extends App
{
  val student = new CollgeStudent("Akash","Dubey")
  val student2 = new Person("Aarushi","Dubey") with Hostler

  println(student)
  println(student2)

}

class Person(val name:String, val surname :String)
trait Hostler
{
  self :Person =>
  val livesInHostel : Boolean =true

  override def toString: String = s"$name -> : $surname :-> $livesInHostel"
}

//class CollegeStudent with Hostler won't compile
//class CollgeStudent(n:String,s:String) with Hostler

class CollgeStudent(n:String,s:String) extends Person(n,s) with Hostler
