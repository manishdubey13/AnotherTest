package com.mani.scala.oops

class ApplyExample
{
  def calculateArea(s : ApplyRectangle) =
  {
     val ar =new ApplyRectangleAreaCalculator()
    ar.apply(s)
  }

}
class ApplyRectangle(val length : Double, val breadth : Double)
class ApplyRectangleAreaCalculator
{
  def apply (ar :ApplyRectangle ) =ar.length*ar.breadth
}

object ApplyExample extends App
{
  val area =  new ApplyExample

  val a = new ApplyRectangle(2,3)

  val aa = area.calculateArea(a)

  print(aa)


}