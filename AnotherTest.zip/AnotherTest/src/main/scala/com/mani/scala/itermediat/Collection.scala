package com.mani.scala.itermediat

object Collection extends App
{

  val list = List.newBuilder[Int]

   list +=5

  list++=Seq(1,2,3,4,5)
    println(list.result)
}
