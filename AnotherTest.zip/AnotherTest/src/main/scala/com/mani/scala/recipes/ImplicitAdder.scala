package com.mani.scala.recipes

object ImplicitAdder extends App
{

  implicit val a= new Adder[Int] {
    override def add(a: Int, b: Int): Int = a+b
  }

  def addThwoThings[T](a :T,b:T) (implicit aa : Adder[T]) =
  {
    aa.add(a,b)
  }

  println(addThwoThings(4,5))
}

trait Adder[T]
{
  def add(a:T,b:T) :T
}

