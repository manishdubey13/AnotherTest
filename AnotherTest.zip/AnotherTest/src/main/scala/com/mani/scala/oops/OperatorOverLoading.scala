package com.mani.scala.oops

class OperatorOverLoading
{

}

class ComplexNumber(val realNum : Double, val imaginary : Double)
{
  def +(that : ComplexNumber)=
  {
    new ComplexNumber(this.realNum+ that.realNum,this.imaginary+that.imaginary)
  }

  override def toString: String = s"$realNum $imaginary"
}
 object OperatorOverLoading extends App
 {
   val c1 = new ComplexNumber(4.5,.001)
   val c2 = new ComplexNumber(0.5,.009)


   print(c1+c2)
 }