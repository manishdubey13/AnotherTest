package com.mani.scala.recipes

object TypeExample extends App
{
  def builNumber1=Three
  println(builNumber1.toInt)

  def buildNumber :Option[Int]=Some(3)
  def doAddition={
    for{
      n1 <- buildNumber
      n2 <- buildNumber
    }yield{
      n1+n2
    }
  }
  def doAddition2 :Int={
    (buildNumber,buildNumber) match
    {
      case (Some(a),Some(b)) =>a+b
      case _ =>0
    }
  }
  println(doAddition)
  println(doAddition2)

  println(timer(doAddition2 _))
  println(timer(doAddition _))

  def timer[T](fn:()=>T) : T=
  {
    val t1 = System.currentTimeMillis()
    val retval = fn()

    Thread.sleep(100)
    val t2 = System.currentTimeMillis()

    val t = t2-t1

    println(s" time Taken  $t")
    retval

  }

  val animals: List[Animal] = List(Dog,Cat,Horse,Cow)

  println(animals)


  /*
  * to filter out the specif subtypes
  * */
  val farmAnimals = animals.collect{
    case fa : FarmAnimal => fa
  }
  println(farmAnimals)


}
case object Three { def toInt=3}
trait Animal
case object Dog extends Animal
case object Cat extends Animal
trait FarmAnimal extends Animal
case object Cow extends FarmAnimal
case object Horse extends FarmAnimal



