/*
package com.mani.scala.oops

class Rectangle(val l : Double, val b : Double)
{
  def this(s:Double)=this(s,s)
  def area():Double=l*b

  override def toString: String = s"Am rectangle with length $l and breadth $b"
}

object Rectangle extends App
{
  val r = new Rectangle(2,3)

  val listOfRec= List(new Rectangle(4,5),r,new Rectangle(2))

  val areas = listOfRec.map(_.area)

  areas.foreach(println(_))

  //println(r.toString)
  //print(r.area)

}*/
