package com.mani.scala.recipes

/*Value class : extends AnyVal used for optimization
don’t need to instantiation in some case only it’s required.
@ case class MyVal(s: Int) extends AnyVal

Different type argument not supported
Only one val parameter

case class MyVal(s: Int,d : Double) extends AnyVal
cmd50.sc:1: value class needs to have exactly one val parameter
case class MyVal(s: Int,d : Double) extends AnyVal

case class MyVal(s: Int,d : Double) extends AnyVal
cmd50.sc:1: value class needs to have exactly one val parameter
case class MyVal(s: Int,d : Double) extends AnyVal

class anotherVal(i: Int) extends AnyVal //no case class
cmd51.sc:1: value class parameter must be a val and not be private[this]

@ class anotherVal(val i: Int) extends AnyVal
defined class anotherVal

when pattern matching using match , class instance will be created, otherwise most of case's not.
*/

object ValueClassExample extends App
{
    println(new AnotherVal(10).withExtraToken)
}

trait MyUniversalTrait extends Any {
  def int: Int
  def withExtraToken = int + 5
}
class AnotherVal(val int: Int) extends AnyVal with MyUniversalTrait
