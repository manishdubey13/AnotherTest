package com.mani.scala

import java.time.{LocalDate, LocalDateTime}

object ClosuresExample extends App
{


  def greet(lang : String)  =
  {
    val time = LocalDateTime.now()
    lang match
    {
      case "English"=> (x: String) =>  "Hello " + time
      case "Hindi" => (x: String) =>  "Namaste "  + time
      case _ => throw new IllegalArgumentException

    }
  }

 val greetEng = greet("English")
  val greeted = greetEng("Manish")
  println(greeted)
}
