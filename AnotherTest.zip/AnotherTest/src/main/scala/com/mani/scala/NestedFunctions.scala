package com.mani.scala

object NestedFunctions extends App
{

  def getCircleStats(r : Double):(Double,Double)=
  {
    val PI =3.14
    def getCircleArea(radius : Double):Double= PI*r*r
    def getCircleCircumferences(radius : Double) : Double =2*PI*r

    (getCircleArea(r),getCircleCircumferences(r))
  }

  val (area,circumferences) =getCircleStats(4)

  println(s"Area is : $area  Circumferences $circumferences ")
}
