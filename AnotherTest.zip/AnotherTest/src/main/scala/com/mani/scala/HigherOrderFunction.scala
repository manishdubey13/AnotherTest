package com.mani.scala

object HigherOrderFunction extends App
{

  def stringCompare(str1 :String,str2:String) :Int=
  {
    if(str1==str2) 0
    else if(str1<str2) -1
    else 1
  }

  def stringCompareDec(str1 :String,str2:String) :Int=
  {
    if(str1==str2) 0
    else if(str1<str2) 1
    else -1
  }

  val comp = stringCompare("mani","mani")
  println(s"$comp")

//Taking function as one of the argument in method
  def smartCompare(str1 : String,str2 : String ,cpm :(String, String) =>Int):Int=
  {
    cpm(str1,str2)
  }

  val callSmartCompare = smartCompare("mani","mani1",stringCompare)

  println(s"$callSmartCompare")

  def orderCompare(order : Boolean):(String,String)=>Int=
  {
    if (order) stringCompare
    else stringCompareDec
  }


  val callOrderCompare = orderCompare(true)

println(callOrderCompare.apply("mani","mani"))


  //Anonymous function assigned to val
  val simpleCompare =(s1: String,s2:String)=>
    {
      if(s1==s2) 0
      else if(s1<s2) -1
      else 1
    }:Int

  println(simpleCompare("mani","mani"))
}
