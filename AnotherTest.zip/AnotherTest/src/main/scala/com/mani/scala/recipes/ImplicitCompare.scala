package com.mani.scala.recipes

case class Person(name:String)
object ImplicitCompare extends App
{
  implicit val personOrdering =
    new Ordering[Person]
    {
      def compare (a :Person,b : Person) =
    {
      implicitly[Ordering[String]].compare(b.name,a.name)
    }
    }

 val v = List(new Person("a"),new Person("z")).sorted

v.foreach(a => println(a.name))

}

