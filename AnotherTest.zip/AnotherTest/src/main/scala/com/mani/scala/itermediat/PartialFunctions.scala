package com.mani.scala.itermediat

object PartialFunctions extends App
{
  case class Animal(name:String,age : Int,species:String)

  val kitty = Animal("ketty",12,"Cat")
  def meow(animal: Animal) :String =
  {
    "meow"
  }

  val meow1  : PartialFunction[Animal,String]=
  {
    case Animal(_,_,"Cat") => "Mew!!"
    case Animal(_,_,"Lion") => "Mew!!"
  }

  val wolf  : PartialFunction[Animal,String]=
  {
    case Animal(_,_,"Dog") => "wolf!!"
  }
  val doggy  = Animal("doggy",12,"Dog")


  println(meow1(kitty))
 // println(meow1(doggy)) //throws an exception
  println(meow1.isDefinedAt(Animal("dx",5,"Elephant"))) //false

  val speak = meow1 orElse wolf

 println( speak.applyOrElse(Animal("fishy",4,"fish"),(x:Animal)=>"Unknown Sound"))


}
