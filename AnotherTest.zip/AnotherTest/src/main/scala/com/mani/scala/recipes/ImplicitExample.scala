package com.mani.scala.recipes

object ImplicitExample extends App
{
  implicit val greet ="Hello !! "
  //implicit val greet1 ="HI !! "

  ///implicitly[String]  to check how many implicit val available of that type

  //will use any implicit val available in scope of same type.
  def greet(s:String)(implicit g : String)={ s +g }
  println(greet("Manish " ))
}
