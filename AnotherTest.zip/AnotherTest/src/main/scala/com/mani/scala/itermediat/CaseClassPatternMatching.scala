package com.mani.scala.itermediat

object CaseClassPatternMatching extends App
{

  case class Animal(name:String,age : Int,species:String)

  def describeAnimal(animal : Animal):String =
  {
    animal match
    {
      case Animal(name,age,species @"Cat") => s"$name is $species and $age old : Mewooo"
      case Animal(name,age,species @"Dog") => s"$name is $species and $age old : Vwooo Vwooo"
      case Animal(name,age,species) => s"$name is $species and $age old"
    }
  }

  println(describeAnimal(Animal("Bob",12,"Cat")))
  println(describeAnimal(Animal("Bob",12,"Dog")))
  println(describeAnimal(Animal("Bob",12,"Cow")))

  //: String = "Bob is Dog and 12 old"


}

