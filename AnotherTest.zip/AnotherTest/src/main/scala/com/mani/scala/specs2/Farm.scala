package com.mani.scala.specs2

class Farm(name : String)
{
  def taskForTheDay(animals : Seq[Animal]): Seq[FarmTask]=
  {
    animals.flatMap
    {
      case animal @ Animal(_,_,Cow) => Seq(FarmTask(animal,"milking"))
      case animal @ Animal(_,_,Cat) => Seq(FarmTask(animal,"mowing"))
      case animal @ Animal(_,_,Horse) => Seq(FarmTask(animal,"plowing"))
      case animal @ Animal(_,_,Chicken) => Seq(FarmTask(animal,"laying eggs"))
      case _ =>Seq()
    }
  }

}
