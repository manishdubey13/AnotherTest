package com.mani.scala.jobs

class Factorial
{

}

object Factorial extends App
{
  def factorial(num : Long) : Long =
  {
    //f = f * f-1
    @annotation.tailrec
    def go(num : Long , acc :Long) : Long =
    {
      if (num <= 0) acc
      else go(num-1,num * acc)
    }
    go(num,1)
  }

  println(factorial(0))
}