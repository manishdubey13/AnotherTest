package com.mani.scala

object Currying extends App
{

  //two or more parameter groups def method()()
  def compareString(comp:(String,String)=>Int)(s1:String,s2:String):Int=
  {
    comp(s1,s2)
  }

  def compString(s1:String,s2:String): Int =
  {
    if(s1==s2) 0
    else if (s1<s2) -1
    else 1
  }

  val fixCompre= compareString(compString)(_:String,_:String)
  val fixStringForCompare = compareString(_:(String,String)=>Int)("mani","mani")


  println(fixCompre("mani","mani2"))
  println(fixStringForCompare(compString))
}
