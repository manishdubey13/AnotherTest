package com.mani.scala

object PartiallyAppliedFunction extends App
{

  def compareString(str1 : String, str2 : String, comp :(String,String)=>Int) : Int=
  {
    comp(str1,str2)
  }

  def myComp (s1 : String,s2:String): Int=
  {
    if (s1==s2) 0
    else if (s1<s2) -1
    else 1
  }
  //
  val partialDef = compareString(_:String,_:String,myComp)

  println(partialDef("mani","mani"))
}
