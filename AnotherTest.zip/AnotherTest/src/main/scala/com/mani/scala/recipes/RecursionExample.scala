package com.mani.scala.recipes

object RecursionExample extends App
{

  val myTree = Branch(Seq(Leaf("Helo"),Branch(Seq(Leaf("Hi"),Leaf("Bye")))))
  val myTree1 = Seq( Branch(Seq(Leaf("Helo"),Branch(Seq(Leaf("Hi"),Leaf("Hi"))))))
  println(uniqueContent(myTree))


  var r = Branch(Seq.empty)
   for (i <- 1 to 4000){r = Branch((Seq(r)))}

  //println(uniqueContent(r))
  //println(trUniqueContent(myTree1))
  println(trUniqueContent(Seq(r)))

  def uniqueContent(root : TreeEntry) : Set[String]=
  {
      root match
      {
        case Branch(children) => children.foldLeft(Set[String]())( _ ++ uniqueContent(_))
        case Leaf(content) => Set(content)
        case _ => Set.empty
      }
  }

 @annotation.tailrec def trUniqueContent(currentLevel : Seq[TreeEntry],seenSofar : Set[String]=Set.empty): Set[String]=
  {
    currentLevel match
    {
      case Seq(Branch(children),rest @ _*)=>
        trUniqueContent(children ++ rest,seenSofar)
      case Seq(Leaf(content), rest @ _*)=>
        trUniqueContent(rest, seenSofar + content)
      case _ => seenSofar
    }
  }

}

sealed trait TreeEntry
case class Branch (children : Seq[TreeEntry]) extends TreeEntry
case class Leaf(content : String) extends TreeEntry

