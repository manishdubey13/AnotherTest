package com.mani.scala.itermediat

object CustomMatchPattern extends App
{

  case class Animal(name:String,species:String)

  object FarmAnimal //Special; case
  {
    def unapply(arg: Animal): Option[Animal] =
    {
      if (arg.species =="Cow")
      {
          Some(arg)
      }else
      {
        None
      }
    }
  }
  object FarmTasks
  {
    def unapplySeq(arg: Animal): Option[Seq[String]] =
    {
      if (arg.species =="Cow")
      {
        Some(Seq("milking","breading","fertilizing"))
      }else
      {
        None
      }
    }
  }
  def namesOffFarmAnimals(animals : Seq[Animal] ): Seq[String]=
    {
      animals.filter
      {
        case FarmAnimal(_) => true
        case _ => false
      }.map{
        case FarmAnimal(Animal(name,species)) => s"$name is $species "
        case _=> ""
      }
    }
  def farmTasksWithAnimal(animals: Seq[Animal]):Seq[String]=
  {
    animals.filter
    {
      case FarmTasks(_,_,_) => true
      case _ => false
    }.map
      {
        case FarmTasks(task1,task2,task3) => s"$task1 : $task2 : $task3 "
        case _ => ""
      }
    }
  val allAnimals = Seq(Animal("Rama","Cow"),Animal("Shyama","Cow"),Animal("Raja","Dog"),Animal("Sikandar","Horse"))

  println(namesOffFarmAnimals(allAnimals))
  println(farmTasksWithAnimal(allAnimals))
  }



