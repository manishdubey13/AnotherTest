package com.mani.scala.itermediat

object PatternMatchingWithCollection extends App
{

  val myList = 1::2::3::5::5::Nil
  myList match  //skips 2nd and anything after third element of list
  {
    case a::_::b::_ => a+b
  }

  val seq = Seq(1,2,3,4,5)
  //res56: Int = 4
//take the first two element from the sequence and do the operation, put the rest of the elements in rest
  seq match
  {
    case Seq(a,b,rest @ _*) =>
    {
      println(rest)
      a+b
    }
  }
}
