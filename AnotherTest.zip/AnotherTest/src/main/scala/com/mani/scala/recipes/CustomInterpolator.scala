package com.mani.scala.recipes


object CustomInterpolator extends App
{
  val name ="Manish"
  val test = "TEST"
  implicit class myInterpolator(val sc : StringContext){
    def m(parameters : Any*)=
    {
      println(sc.parts)
      println(parameters)

      sc.parts.zipAll(parameters,"","").map{
        case (param,"") => param
        case (parts,"") =>parts
        case (parts,param) => s"$parts :magic : $param"
      }.mkString("\n")
    }
  }
  //here we made efficient by making it value class, so it don't need instantiation, work's same as static
  // where ever m1 is used
  implicit class myInterpolator1(val sc : StringContext) extends AnyVal {
    def m1(parameters : Any*)=
    {
      println(sc.parts)
      println(parameters)

      sc.parts.zipAll(parameters,"","").map{
        case (param,"") => param
        case (parts,"") =>parts
        case (parts,param) => s"$parts :magic : $param"
      }.mkString("\n")
    }
  }
  println(m" Hello $name $name $test test")
  println(m1" Hello $name $name $test test")
}

