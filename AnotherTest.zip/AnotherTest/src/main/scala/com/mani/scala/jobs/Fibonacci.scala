package com.mani.scala.jobs

import scala.annotation.tailrec

object Fibonacci extends App
{
  println(fibbo(1312))

  def fibbo( num : Int) : BigInt =
  {

   // f = (f-1) + (f-2)
    @tailrec
    def go(f: Int,pre :BigInt= 0, next:BigInt = 1) : BigInt =
    {
      f match
      {
        case 0 => pre
        case 1 => next
        case _ => go(f - 1, next, (pre + next))
      }
    }
    go(num)
  }
}
