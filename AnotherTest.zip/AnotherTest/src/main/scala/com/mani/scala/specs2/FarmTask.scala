package com.mani.scala.specs2

case class FarmTask(animal : Animal,description : String)