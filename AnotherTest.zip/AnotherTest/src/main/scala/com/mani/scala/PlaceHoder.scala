package com.mani.scala

object PlaceHoder extends App
{

  def isVip(name:String,lastName:String,isImportant:(String,String)=>Boolean):Boolean=
{
    isImportant(name,lastName)
}
  val isRealVip= isVip("manish","dubey",_=="manish" && _=="dubey")


  println(isRealVip)
}
