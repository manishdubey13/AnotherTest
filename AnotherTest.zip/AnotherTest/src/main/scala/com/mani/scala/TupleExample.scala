package com.mani.scala

object TupleExample extends App
{

  val personInfo =("Manish","Dubey","Seoni","India")

  val (name,lastname,city,country) =personInfo
  println(s" Prrson Details name $name  Country $country" )

  val (name1,_,_,country1) =personInfo
  println(s" Prrson Details name $name  Country $country" )

  val keyPairTuple = "Manish" -> "India"

  def printPersonDetails(name : String, country : String)=
  {
    println(s" Name : $name  Country : $country")
  }
   //remember this syntax
  (printPersonDetails _).tupled(keyPairTuple)



}
