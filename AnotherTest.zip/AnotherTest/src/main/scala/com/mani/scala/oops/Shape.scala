package com.mani.scala.oops

abstract class Shape(val name : String)
{
  override def toString: String = s" my Name is $name"
  def area:Double
}

class Rectangle(l:Double,b:Double,name : String ="Rectangle") extends Shape(name)
{
  def area():Double = l * b

  override def toString: String = s" My Name is $name"
}

class Square (side : Double) extends Rectangle(side,side,"Square")
{
  override def toString: String = s" My Name is $name"
}

object Shape extends App
{
  val s : Shape =new Square(2)
  val s1 : Shape = new Rectangle(2,3)

  val unknownShape = new Shape("unknownShape")
  {
    override def area: Double = 100
  }

  println(s.toString +  " with Area " +s.area)
  println(s1.toString +  " with Area " +s1.area )
  println(unknownShape.toString +  " with Area " +unknownShape.area )


}