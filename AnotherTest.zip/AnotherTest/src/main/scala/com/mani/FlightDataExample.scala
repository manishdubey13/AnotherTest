package com.mani

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SparkSession

object FlightDataExample extends App
{

  var appname="FihghtData"
  lazy val sparkConf: SparkConf = new SparkConf()
    .setAppName(appname)
    .setMaster("local[*]")

  lazy val sparkSession: SparkSession = SparkSession
    .builder()
    .config(sparkConf)
    .enableHiveSupport()
    .getOrCreate()

  val sc: SparkContext = sparkSession.sparkContext



  val airlines = sc.textFile("file:///Users/manish/spark/FlightsData/airlines.csv")
  val myAirlines = airlines.filter(myFilter(_,"Description")).take(5)
  //val myFlightData = flight.collect()

  myAirlines.foreach(line=>println(line))
  //check flight data

 /* val fewLines = myFlightData.tail(5)

  fewLines.foreach(line =>print(line))
*/

  def myFilter(line:String,stringNotToMatch:String): Boolean =
  {
      !line.contains(stringNotToMatch)
  }
}
