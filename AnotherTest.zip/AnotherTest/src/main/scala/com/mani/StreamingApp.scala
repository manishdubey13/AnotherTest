package com.mani

import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object StreamingApp extends App
{
  val appName= "StreamingApp";

  lazy val config = new SparkConf().setAppName(appName).setMaster("local[*]")
  lazy val sc = new SparkContext(config)


  val ssc = new StreamingContext(sc,Seconds(10)) //batch of 1 second

  ssc.checkpoint("file:///Users/manish/spark/stream/")

  val line = ssc.socketTextStream("localhost",9999)
  //Stateless
  //val errors = line.filter(_.contains("Error")).flatMap(_.split(" ")).map(word =>(word,1)).reduceByKey((x,y) =>x+y)

  //Stateful

  val errors = line.filter(_.contains("Error")).flatMap(_.split(" ")).map(word =>(word,1))
                .reduceByKeyAndWindow({(x,y) =>x+y},{(x,y)=>x-y},Seconds(60),Seconds(10))

  errors.print()

  ssc.start()
  ssc.awaitTermination()

}
