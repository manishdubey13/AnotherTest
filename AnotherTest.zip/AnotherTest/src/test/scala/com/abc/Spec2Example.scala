package com.abc

import org.specs2.mutable.Specification
import com.mani.scala.specs2._

class FarmSpecs extends Specification
{
  "Farm" should
    {
      val farm = new Farm("MyFarm")
        "extract task for cow " in
          {
            val cow = Animal("Rama", 12, Cow)

            farm.taskForTheDay(Seq(cow)) must_== Seq(FarmTask(cow, "milking"))
            farm.taskForTheDay(Seq(cow)) must have size (1)
          }

        "extract task description for multiple animals" in
        {
          val cow = Animal("Rama", 12, Cow)
          val cat = Animal("catty", 12, Cat)
          val horse = Animal("Horsy", 12, Horse)

          farm.taskForTheDay(Seq(cow,cat,horse)) must beLike
          {
            case Seq(FarmTask(_,cowDes),FarmTask(_,catDes),FarmTask(_,hoDes)) =>
              cowDes must_== "milking"
              catDes must_== "mowing"
              hoDes must_== "plowing"
          }
        }
    }
}
