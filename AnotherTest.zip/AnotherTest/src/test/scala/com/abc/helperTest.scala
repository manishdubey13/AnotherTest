package com.abc

import org.scalatest.FunSuite
import org.scalatest.BeforeAndAfter



class helperTest extends FunSuite with Context {

  import sparkSession.implicits
  test("testGetBucketKey") {

  val (bucketResult,keyResult) = helper.getBucketKey("s3a://s3-xe1-nprd-lif-datalake/Sourcecdc/Current/CONSUMER/LHD/Americas/Channel_Management/Sircon/producer_individual/Baseline")
  val bucket="s3-xe1-nprd-lif-datalake"

    assert(bucket.equals(bucketResult))

  }

  /*test("testselectAny") {

    val sessionsDF = Seq(("day1","user1","session1", 100.0),
      ("day1","user1","session2",200.0),
      ("day2","user1","session3",300.0),
      ("day2","user1","session4",400.0),
      ("day2","user1","session4",99.0)).toDF("day","userId","sessionId","purchaseTotal")
  }

   val resultDF=helper.selectAny(sessionsDF)*/


}
