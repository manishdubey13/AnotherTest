package com.abc

import org.scalatest.FunSuite

class tableoperationsTest extends FunSuite {


}
